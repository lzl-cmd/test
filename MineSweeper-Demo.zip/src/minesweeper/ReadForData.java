package minesweeper;

import components.GridComponent;
import entity.GridStatus;

public class ReadForData {
    private String data;
    private String[] grid;
    private String[] basic;
    private String[][] grids;
    private String[] gridNum;
    private String[][] gridNums;
    private int xCount;
    private int yCount;
    private int mineCount;
    private GridComponent[][] gridComponents;
    private MainFrame mainFrame;

    public ReadForData(){

    }
    public ReadForData(String str) {
        this.data = str;
    }
    public void initGridComponent(){
        for (int i = 0; i < xCount; i++) {
            for (int j = 0; j < yCount; j++) {
                GridComponent gridComponent = new GridComponent(i, j, xCount, yCount);
                gridComponents[i][j] = gridComponent;
            }
        }
    }
    public void getBasic(String str) {
        this.basic = str.split(" ");
    }
    public void getGrid(String str) {
        this.grid = str.split(" ");
    }
    public void getGridNum(String str) {
        this.gridNum = str.split(" ");
    }

    public void readDataForBasic(String str) {
        getBasic(str);
        this.xCount = Integer.parseInt(this.basic[0]);
        this.yCount = Integer.parseInt(this.basic[1]);
        this.mineCount = Integer.parseInt(this.basic[2]);
        this.gridComponents = new GridComponent[xCount][yCount];
        this.grids = new String[xCount][yCount];
        this.gridNums = new String[xCount][yCount];
    }

    public void readDataForGrid(String str){
        getGrid(str);
        one2Two(grid,grids);
        initGridComponent();
        for (int i = 0; i < xCount; i++) {
            for (int j = 0; j < yCount; j++) {
                gridComponents[i][j].setStatus(Enum.valueOf(GridStatus.class,grids[i][j]));
            }
        }
    }
    public void readDataForGridNum(String str) {
        getGridNum(str);
        one2Two(gridNum,gridNums);
        for (int i = 0; i < xCount; i++) {
            for (int j = 0; j < yCount; j++) {
                gridComponents[i][j].setContent(Integer.parseInt(gridNums[i][j]));

            }
        }
    }
    public void readDataForPlayer(String str){

    }

    public boolean checkForGrid(String grid) {

        if (MainFrame.controller.getGamePanel().getxCount() != this.xCount) {
            return false;
        }
        if (MainFrame.controller.getGamePanel().getyCount() != this.yCount) {
            return false;
        }
        for (int i = 0; i < this.xCount; i++) {
            for (int j = 0; j < this.yCount; j++) {
                if(!this.gridComponents[i][j].getStatus().equals(MainFrame.controller.getGamePanel().mineField[i][j].getStatus())){
                    return false;
                }
            }
        }
        return true;
    }


    public void creatMainFrame() {
        MainFrame mainFrameSavedBefore = new MainFrame(mineCount);
        for (int i = 0; i < xCount; i++) {
            for (int j = 0; j < yCount; j++) {
                mainFrameSavedBefore.getGamePanel().mineField[i][j].setStatus(this.gridComponents[i][j].getStatus());
                mainFrameSavedBefore.getGamePanel().mineField[i][j].setContent(this.gridComponents[i][j].getContent());
                mainFrameSavedBefore.getGamePanel().setChessboard(this.gridComponents[i][j].getContent(),i,j);
            }
        }
        mainFrameSavedBefore.setVisible(true);
    }


    public static void one2Two(String[] data, String[][] da) {
        int k = 0;
        int hang = da.length;
        int lie = da[0].length;
        for (int i = 0; i < hang; i++) {
            for (int j = 0; j < lie; j++) {
                da[i][j] = data[k];
                k++;
            }
        }
    }


}
