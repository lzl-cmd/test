package minesweeper;

import components.GridComponent;

public class SaveForData {
    private int xCount;
    private int yCount;
    private int mineCount;
    private MainFrame mainFrame;
    private GridComponent[][] gridComponents;
    private String basic;
    private String[][] grid;
    private String gridForAll;
    private String[][] gridNum;
    private String gridNumForAll;
    private String player[];
    private String playerScore[];
    private String mistake[];
    private String timeLeft;
    private String playerStatus;

    public SaveForData(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        this.xCount = mainFrame.getxCount();
        this.yCount = mainFrame.getyCount();
        this.mineCount = mainFrame.getMineCount();
        this.gridComponents = new GridComponent[xCount][yCount];
        this.gridNum = new String[xCount][yCount];
        this.grid = new String[xCount][yCount];
    }

    public void setGrid(GridComponent[][] grid) {
        for (int i = 0; i < mainFrame.getxCount(); i++) {
            for (int j = 0; j < mainFrame.getyCount(); j++) {
                this.gridComponents[i][j] = grid[i][j];
                this.gridNum[i][j] = String.valueOf(grid[i][j].getContent());
            }
        }
    }

    public String turnStringForBasic() {
        basic = xCount + " " + yCount + " " + mineCount;
        return basic;
    }

    public String turnStringForGrid() {
        setGrid(mainFrame.getGamePanel().mineField);
        for (int i = 0; i < mainFrame.getxCount(); i++) {
            for (int j = 0; j < mainFrame.getyCount(); j++) {
                grid[i][j] = gridComponents[i][j].getStatus().toString();
            }
        }
        gridForAll = grid[0][0] + " ";
        for (int i = 0; i < mainFrame.getxCount(); i++) {
            for (int j = 0; j < mainFrame.getyCount(); j++) {
                if (j == 0 && i == 0) {
                    continue;
                }
                gridForAll = gridForAll.concat(grid[i][j] + " ");
            }
        }
        return gridForAll;
    }

    public String turnStringForGridNum() {

        gridNumForAll = gridNum[0][0] + " ";
        for (int i = 0; i < mainFrame.getxCount(); i++) {
            for (int j = 0; j < mainFrame.getyCount(); j++) {
                if (j == 0 && i == 0) {
                    continue;
                }
                gridNumForAll = gridNumForAll.concat(gridNum[i][j] + " ");
            }
        }
        return gridNumForAll;
    }

    public void setPlayerStatus() {
        for (int i = 0; i < MainFrame.controller.getPlayer().length; i++) {
            player[i] = MainFrame.controller.getPlayer()[i].getUserName();
        }
        for (int i = 0; i < MainFrame.controller.getPlayer().length; i++) {
            playerScore[i] = String.valueOf(MainFrame.controller.getPlayer()[i].getScore());
        }
        for (int i = 0; i < MainFrame.controller.getPlayer().length; i++) {
            mistake[i] = String.valueOf(MainFrame.controller.getPlayer()[i].getMistake());
        }
    }

    public String turnStringForPlayers() {
        setPlayerStatus();
        for (int i = 0; i < MainFrame.controller.getPlayer().length; i++) {
            playerStatus = playerStatus.concat(player[i] + " " + playerScore[i] + "" + mistake[i]);
        }
        return playerStatus;
    }


}
