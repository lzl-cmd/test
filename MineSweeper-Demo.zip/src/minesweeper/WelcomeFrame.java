package minesweeper;


import javax.swing.*;
import java.awt.*;

public class WelcomeFrame extends JFrame {
    private JComboBox<String> difficulty;
    private JLabel label;
    private static final int DEFAULT_SIZE = 24;

    public WelcomeFrame() {
        label = new JLabel("难度");
        label.setFont(new Font("简单", Font.PLAIN, DEFAULT_SIZE));
        add(label, BorderLayout.CENTER);

        difficulty = new JComboBox<>();
        difficulty.addItem("简单");
        difficulty.addItem("中等");
        difficulty.addItem("困难");
        difficulty.addItem("自定义");

        difficulty.addActionListener(event -> {
                    switch (difficulty.getSelectedIndex()) {
                        case 0: {
                            MainFrame mainFrame = new MainFrame(10);
                            mainFrame.setVisible(true);
                            break;
                        }
                        case 1: {
                            MainFrame mainFrame = new MainFrame(40);
                            mainFrame.setVisible(true);
                            break;
                        }
                        case 2: {
                            MainFrame mainFrame = new MainFrame(99);
                            mainFrame.setVisible(true);
                            break;

                        }
                        case 3: {
                            MainFrame mainFrame = new MainFrame(99);
                            mainFrame.setVisible(true);

                        }

                    }

                }
        );
        JPanel comboPanel = new JPanel();
        comboPanel.add(difficulty);
        add(comboPanel, BorderLayout.SOUTH);
        pack();
        this.setTitle("扫雷");
        this.setLayout(null);
        this.setSize(300, 500);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}