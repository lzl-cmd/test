package components;

import entity.GridStatus;
import minesweeper.MainFrame;

import javax.swing.*;
import java.awt.*;

public class GridComponent extends BasicComponent {
    public static int gridSize = 30;
    private final int xCount;
    private final int yCount;
    private static ImageIcon flag = new ImageIcon("D:\\ideaprojecket\\saolei1\\flag.jpg");
    private static ImageIcon bomb = new ImageIcon("D:\\ideaprojecket\\saolei1\\bomb.jpg");
    private static ImageIcon lucency = new ImageIcon("D:\\ideaprojecket\\saolei1\\lucency.png");
    private int row;
    private int col;
    private GridStatus status = GridStatus.CoveredWithGrid;
    private int content = 0;

    public GridComponent(int x, int y, int xCount, int yCount) {
        this.setSize(gridSize, gridSize);
        this.row = x;
        this.col = y;
        this.xCount = xCount;
        this.yCount = yCount;
    }

    public GridStatus getStatus() {
        return status;
    }


    public void setStatus(GridStatus status) {
        this.status = status;
    }


    @Override
    public void onMouseLeftClicked() {
//        MainFrame.controller.testForInitial();
        System.out.printf("Gird (%d,%d) is left-clicked.\n", row, col);
        if (this.status == GridStatus.CoveredWithGrid) {
            this.status = GridStatus.Clicked;
            System.out.println(this.content);
            MainFrame.controller.openAll(row, col);
            repaint();
            MainFrame.controller.nextTurn();
        }
        if (this.status == GridStatus.CoveredWithMine || this.status == GridStatus.CheatOnMine) {
            if (MainFrame.controller.creatAgain()) {
                MainFrame.controller.repaintForFirstClickOnMine(row, col);
                this.status = GridStatus.Clicked;
                MainFrame.controller.openAll(row, col);
                repaint();
            } else {
                System.out.println("点到雷了");
                this.status = GridStatus.ClickedOnMine;
                repaint();
                MainFrame.controller.nextTurn();
            }
        }
        //TODO: 在左键点击一个格子的时候，还需要做什么？

    }

    @Override
    public void onMouseRightClicked() {
        System.out.printf("Gird (%d,%d) is right-clicked.\n", row, col);
        if (this.status == GridStatus.CoveredWithGrid) {
            System.out.println("旗子插错了");
            this.status = GridStatus.FlagOnGrid;
            repaint();
            MainFrame.controller.nextTurn();
        }
        if (this.status == GridStatus.CoveredWithMine||this.status == GridStatus.CheatOnMine) {
            this.status = GridStatus.FlagOnMine;
            repaint();
            MainFrame.controller.nextTurn();
        }
        //TODO: 在右键点击一个格子的时候，还需要做什么？
    }

    public void draw(Graphics g) {

        if (this.status == GridStatus.CoveredWithGrid) {
            g.setColor(Color.CYAN);
            g.fillRect(0, 0, getWidth() - 1, getHeight() - 1);
        }
        if (this.status == GridStatus.Clicked) {
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, getWidth() - 1, getHeight() - 1);
            g.setColor(Color.BLACK);
            g.drawString(Integer.toString(content), getWidth() / 2 - 5, getHeight() / 2 + 5);

        }
        if (this.status == GridStatus.Flag) {

            g.setColor(Color.LIGHT_GRAY);
            g.fillRect(0, 0, getWidth() - 1, getHeight() - 1);
            g.setColor(Color.RED);
            g.drawString("F", getWidth() / 2 - 5, getHeight() / 2 + 5);
        }
        if (this.status == GridStatus.FlagOnMine) {
            g.drawImage(flag.getImage(),0,0,this);
        }
        if (this.status == GridStatus.CoveredWithMine) {

            g.setColor(Color.CYAN);
            g.fillRect(0, 0, getWidth() - 1, getHeight() - 1);
            g.setColor(Color.CYAN);
            g.drawString("F", getWidth() / 2 - 5, getHeight() / 2 + 5);
        }
        if (this.status == GridStatus.ClickedOnMine) {
            g.drawImage(bomb.getImage(),0,0,this);
//            g.setColor(Color.RED);
//            g.fillRect(0, 0, getWidth() - 1, getHeight() - 1);
//            g.setColor(Color.RED);
//            g.drawString("F", getWidth() / 2 - 5, getHeight() / 2 + 5);
        }
        if (this.status == GridStatus.FlagOnGrid) {
            g.setColor(Color.RED);
            g.fillRect(0, 0, getWidth() - 1, getHeight() - 1);
            g.drawImage(flag.getImage(),0,0,this);

            g.setColor(Color.RED);
        }
        if (this.status == GridStatus.CheatOnMine) {
            g.setColor(Color.RED);
            g.fillRect(0, 0, getWidth() - 1, getHeight() - 1);
            g.setColor(Color.RED);
            g.drawString("F", getWidth() / 2 - 5, getHeight() / 2 + 5);
        }

    }

    public int getContent() {
        return content;
    }

    public void setContent(int content) {
        this.content = content;
    }

    @Override
    public void paintComponent(Graphics g) {
        super.printComponents(g);
        draw(g);
    }

}
