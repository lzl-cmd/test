package controller;

import entity.GridStatus;
import minesweeper.GamePanelTwo;
import entity.Player;
import minesweeper.ScoreBoard;

import javax.swing.*;
import java.awt.*;


public class GameControllerTwo {

    private Player p1;
    private Player p2;

    private Player onTurn;
    private final int[][] offset = {{-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}};

    private GamePanelTwo gamePanel;
    private ScoreBoard scoreBoard;

    public GameControllerTwo(Player p1, Player p2) {
        this.init(p1, p2);
        this.onTurn = p1;
    }

    /**
     * 初始化游戏。在开始游戏前，应先调用此方法，给予游戏必要的参数。
     *
     * @param p1 玩家1
     * @param p2 玩家2
     */
    public void init(Player p1, Player p2) {
        this.p1 = p1;
        this.p2 = p2;
        this.onTurn = p1;

        //TODO: 在初始化游戏的时候，还需要做什么？
    }

    /**
     * 进行下一个回合时应调用本方法。
     * 在这里执行每个回合结束时需要进行的操作。
     * <p>
     * (目前这里没有每个玩家进行n回合的计数机制的，请自行修改完成哦~）
     */
    private boolean verify(int row, int col, int xCount, int yCount) {
        return row >= 0 && row < xCount && col >= 0 && col < yCount;
    }

    public void openAll(int row, int col) {
        if (gamePanel.getChessboard(row, col) == 0) {
            for (int[] off : offset) {
                int newRow = row + off[0];
                int newCol = col + off[1];
                if (verify(newRow, newCol, gamePanel.getxCount(), gamePanel.getyCount())) {
                    if (gamePanel.getChessboard(newRow, newCol) != -1 && !gamePanel.mineField[newRow][newCol].getStatus().equals(GridStatus.Clicked)) {
                        gamePanel.mineField[newRow][newCol].setStatus(GridStatus.Clicked);
                        gamePanel.repaint();
                        openAll(newRow, newCol);
                    }

                }
            }
        }
    }

    public void nextTurn() {
        if (onTurn == p1) {
            onTurn = p2;
        } else if (onTurn == p2) {
            onTurn = p1;
        }
        System.out.println("Now it is " + onTurn.getUserName() + "'s turn.");

        scoreBoard.update();
        //TODO: 在每个回合结束的时候，还需要做什么 (例如...检查游戏是否结束？)

    }

    public boolean creatAgain() {
        for (int i = 0; i < gamePanel.getxCount(); i++) {
            for (int j = 0; j < getGamePanel().getyCount(); j++) {
                if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.Clicked)||gamePanel.mineField[i][j].getStatus().equals(GridStatus.ClickedOnMine)||gamePanel.mineField[i][j].getStatus().equals(GridStatus.FlagOnMine)) {
                    return false;
                }

            }
        }
        return true;
    }

    public void repaintForFirstClickOnMine(int row,int col) {

        GamePanelTwo gamePanel1 = new GamePanelTwo(gamePanel.getxCount(), gamePanel.getyCount(), gamePanel.getMineCount());
        for (int i = 0; i <gamePanel.getxCount(); i++) {
            for (int j = 0; j <gamePanel.getyCount(); j++) {
                gamePanel.mineField[i][j].setStatus(gamePanel1.mineField[i][j].getStatus()) ;
                gamePanel.mineField[i][j].setContent(gamePanel1.mineField[i][j].getContent());
                gamePanel.setChessboard(gamePanel1.getChessboard(i,j),i,j);
                gamePanel.repaint();
            }
        }
        if(gamePanel.mineField[row][col].getStatus().equals(GridStatus.CoveredWithMine)){
            repaintForFirstClickOnMine(row,col);
        }

    }

    /**
     * 获取正在进行当前回合的玩家。
     *
     * @return 正在进行当前回合的玩家
     */
    public Player getOnTurnPlayer() {
        return onTurn;
    }


    public Player getP1() {
        return p1;
    }

    public Player getP2() {
        return p2;
    }

    public GamePanelTwo getGamePanel() {
        return gamePanel;
    }

    public ScoreBoard getScoreBoard() {
        return scoreBoard;
    }

    public void setGamePanel(GamePanelTwo gamePanel) {
        this.gamePanel = gamePanel;
    }

    public void setScoreBoard(ScoreBoard scoreBoard) {
        this.scoreBoard = scoreBoard;
    }


    public void readFileData(String fileName) {
        //todo: read date from file

    }

    public void writeDataToFile(String fileName) {
        //todo: write data into file
    }


}


