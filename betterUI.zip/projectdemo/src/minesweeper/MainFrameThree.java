package minesweeper;

import components.GirdComponentThree;
import controller.GameControllerThree;
import entity.GridStatus;
import entity.Player;

import javax.swing.*;
import java.awt.event.ActionListener;

public class MainFrameThree extends JFrame {
    public static GameControllerThree controller;
    private int xCount;
    private int yCount;
    private int mineCount;


    public MainFrameThree(int m) {
        //todo: change the count of xCount, yCount and mineCount by passing parameters from constructor
        this.mineCount = m;

        if (mineCount == 10) {
            this.xCount = 9;//grid of row
            this.yCount = 9;// grid of column
        }

        if (mineCount == 40){
            this.xCount = 16;
            this.yCount = 16;
        }

        if (mineCount == 99){
            this.xCount = 16;
            this.yCount = 30;
        }

        this.setTitle("扫雷");
        this.setLayout(null);
        this.setSize(yCount * GirdComponentThree.gridSize + 20, xCount * GirdComponentThree.gridSize + 200);
        this.setLocationRelativeTo(null);

        Player p1 = new Player();
        Player p2 = new Player();
        Player p3 = new Player();

        controller = new GameControllerThree(p1, p2, p3);
        GamePanelThree gamePanel = new GamePanelThree(xCount, yCount, mineCount);
        controller.setGamePanel(gamePanel);
        ScoreBoardThree scoreBoard = new ScoreBoardThree(p1, p2, p3, xCount, yCount);
        controller.setScoreBoard(scoreBoard);

        this.add(gamePanel);

        this.add(scoreBoard);


        // Change "click" to "Save".
        JButton clickBtn = new JButton("Save");
        clickBtn.setSize(80, 20);
        clickBtn.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight());
        add(clickBtn);
        clickBtn.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            System.out.println("fileName :"+fileName);

//            controller.readFileData(fileName);
//            controller.writeDataToFile(fileName);
        });
        JButton cheat = new JButton("cheat");
        cheat.setSize(80, 20);
        cheat.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight());
        add(cheat);
        cheat.addActionListener(e -> {
            for (int i = 0; i < xCount; i++) {
                for (int j = 0; j < yCount; j++) {
                    if(gamePanel.mineField[i][j].getStatus().equals(GridStatus.CoveredWithMine)){
                        gamePanel.mineField[i][j].setStatus(GridStatus.CheatOnMine);
                        gamePanel.repaint();
                    }
                }
            }
        });

    }

}