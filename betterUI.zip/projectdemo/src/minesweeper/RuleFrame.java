package minesweeper;

import javax.swing.*;
import java.awt.*;

public class RuleFrame extends JFrame{

    public RuleFrame(){

        this.setTitle("扫雷-游戏规则");
        this.setVisible(true);
        this.setLayout(null);
        this.setBounds(700,200,700,440);
        this.setResizable(false);

        JLabel background = new JLabel("游戏规则");
        background.setBounds(0,0,700,394);
        background.setIcon(Data.ruleBackground);
        //background.setIcon(Data.ruleBackground);

        Container container = getContentPane();
        container.add(background);

    }

}

