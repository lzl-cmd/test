package minesweeper;

import components.GirdComponentTwo;
import entity.GridStatus;

import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class GamePanelTwo extends JPanel {
    public GirdComponentTwo[][] mineField;
    private int[][] chessboard;
    private final Random random = new Random();
    private final int[][] offset = {{-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}};
    private int xCount;
    private int yCount;
    private int mineCount;

    /**
     * 初始化一个具有指定行列数格子、并埋放了指定雷数的雷区。
     *
     * @param xCount    count of grid in column
     * @param yCount    count of grid in row
     * @param mineCount mine count
     */
    public GamePanelTwo(int xCount, int yCount, int mineCount) {
        this.setVisible(true);
        this.setFocusable(true);
        this.setLayout(null);
        this.setBackground(Color.WHITE);
        this.setSize(GirdComponentTwo.gridSize * yCount, GirdComponentTwo.gridSize * xCount);
        this.xCount = xCount;
        this.yCount = yCount;
        initialGame(xCount, yCount, mineCount);
        repaint();
        this.mineCount = mineCount;
    }

    public int getxCount() {
        return xCount;
    }
    public void setChessboard(int num,int row,int col){
        this.chessboard[row][col]=num;
    }
    public int getyCount() {
        return yCount;
    }

    public int getMineCount() {
        return mineCount;
    }

    public int getChessboard(int i, int j) {
        return chessboard[i][j];
    }

    public void initialGame(int xCount, int yCount, int mineCount) {
        mineField = new GirdComponentTwo[xCount][yCount];

        generateChessBoard(xCount, yCount, mineCount);

        for (int i = 0; i < xCount; i++) {
            for (int j = 0; j < yCount; j++) {
                GirdComponentTwo girdComponentTwo = new GirdComponentTwo(i, j, xCount, yCount);
                girdComponentTwo.setContent(chessboard[i][j]);
                girdComponentTwo.setLocation(j * GirdComponentTwo.gridSize, i * GirdComponentTwo.gridSize);
                mineField[i][j] = girdComponentTwo;
                if (mineField[i][j] != null) {
                    if (chessboard[i][j] == -1) {
                        mineField[i][j].setStatus(GridStatus.CoveredWithMine);
                    }
                }
                this.add(mineField[i][j]);
            }
        }
    }

    public void initMine(int xCount, int yCount, int mineCount) {
        OUT:
        while (true) {
            // 生成一个随机数表示行坐标
            int rRow = (int) (Math.random() * xCount);
            // 生成一个随机数表示列坐标
            int rCol = (int) (Math.random() * yCount);
            chessboard[rRow][rCol] = -1;
            int num = 0;
            for (int i = 0; i < xCount; i++) {
                for (int j = 0; j < yCount; j++) {
                    if (chessboard[i][j] == -1)
                        num++;
                    if (num == mineCount) {
                        break OUT;
                    }
                }
            }
        }
        if (checkMine()) {
            initMine(xCount, yCount, mineCount);
        }
    }

    public boolean checkMine() {
        for (int i = 0; i < xCount; i++) {
            for (int j = 0; j < yCount; j++) {
                if (chessboard[i][j] == -1) {
                    int bombCount = 0;
                    for (int[] off : offset) {
                        int row = i + off[1];
                        int col = j + off[0];
                        // 判断是否越界,是否为炸弹
                        if (verify(row, col, xCount, yCount) && chessboard[row][col] == -1) {
                            bombCount++;
                        }
                        if (bombCount == 8) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }


    public void generateChessBoard(int xCount, int yCount, int mineCount) {

        //todo: generate chessboard by your own algorithm
        chessboard = new int[xCount][yCount];
        initMine(xCount, yCount, mineCount);
        for (int i = 0; i < xCount; i++) {
            for (int j = 0; j < yCount; j++) {
                // 如果是炸弹,不标注任何数字
                if (chessboard[i][j] == -1) {
                    continue;
                }
                // 如果不是炸弹,遍历它周围的八个方块,将炸弹的总个数标注在这个方格上
                // 方块周围的8个方块中炸弹个数
                int bombCount = 0;
                // 通过偏移量数组循环遍历8个方块
                for (int[] off : offset) {
                    int row = i + off[1];
                    int col = j + off[0];
                    // 判断是否越界,是否为炸弹
                    if (verify(row, col, xCount, yCount) && chessboard[row][col] == -1) {
                        bombCount++;
                    }
                }
                // 如果炸弹的个数不为0,标注出来
                if (bombCount > 0) {
                    chessboard[i][j] = bombCount;
                }
            }
        }

    }

    private boolean verify(int row, int col, int xCount, int yCount) {
        return row >= 0 && row < xCount && col >= 0 && col < yCount;
    }


    /**
     * 获取一个指定坐标的格子。
     * 注意请不要给一个棋盘之外的坐标哦~
     *
     * @param x 第x列
     * @param y 第y行
     * @return 该坐标的格子
     */
    public GirdComponentTwo getGrid(int x, int y) {
        try {
            return mineField[x][y];
        } catch (ArrayIndexOutOfBoundsException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
    }
}

