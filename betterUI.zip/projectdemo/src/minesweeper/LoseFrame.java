package minesweeper;

import javax.swing.*;
import java.awt.*;

public class LoseFrame extends JFrame {

    public LoseFrame(){

        this.setTitle("你输了");
        this.setVisible(true);
        this.setLayout(null);
        this.setBounds(700,400,561,486);
        this.setResizable(false);

        JLabel background = new JLabel();
        background.setBounds(0,0,561,486);
        background.setIcon(Data.lose);

        Container container = getContentPane();
        container.add(background);
    }
}
