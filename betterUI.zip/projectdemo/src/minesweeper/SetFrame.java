package minesweeper;

import javax.swing.*;

public class SetFrame extends JFrame {

    public SetFrame(){

        String x = JOptionPane.showInputDialog(this, "宽度");
        System.out.println("宽度 :"+x);
        String y = JOptionPane.showInputDialog(this, "高度");
        System.out.println("高度 :"+y);
        String z = JOptionPane.showInputDialog(this, "雷数");
        System.out.println("雷数 :"+z);


        int width = Integer.parseInt(x);
        int height = Integer.parseInt(y);
        int number = Integer.parseInt(z);

        MainFrameTwo mainFrameTwo = new MainFrameTwo(width,height,number);
        mainFrameTwo.setVisible(true);

    }


}
