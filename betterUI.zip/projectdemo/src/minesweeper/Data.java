package minesweeper;

import javax.swing.*;
import java.net.URL;

public class Data {

    public static URL startURL = Data.class.getResource("images/startingOne.jpg");
    public static ImageIcon start = new ImageIcon(startURL);
    public static URL oneURL = Data.class.getResource("images/oneoneone.png");
    public static ImageIcon one = new ImageIcon(oneURL);
    public static URL twoURL = Data.class.getResource("images/two.png");
    public static ImageIcon two = new ImageIcon(twoURL);
    public static URL OneText = Data.class.getResource("images/OneText.png");
    public static ImageIcon oneText = new ImageIcon(OneText);
    public static URL TwoText = Data.class.getResource("images/TwoText.png");
    public static ImageIcon twoText = new ImageIcon(TwoText);
    public static URL Title = Data.class.getResource("images/goodTitle.png");
    public static ImageIcon title = new ImageIcon(Title);
    public static URL Difficulty1 = Data.class.getResource("images/11.png");
    public static ImageIcon difficulty1 = new ImageIcon(Difficulty1);
    public static URL RuleButton = Data.class.getResource("images/ruleButton.png");
    public static ImageIcon ruleButton = new ImageIcon(RuleButton);
    public static URL RuleBackground = Data.class.getResource("images/RuleBackground.png");
    public static ImageIcon ruleBackground = new ImageIcon(RuleBackground);
    public static URL Lose = Data.class.getResource("images/lose.png");
    public static ImageIcon lose = new ImageIcon(Lose);

}
