package minesweeper;

import components.GirdComponentThree;
import controller.GameController;
import controller.GameControllerThree;
import entity.GridStatus;
import entity.Player;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.io.File;

public class MainFrameThree extends JFrame {
    public static GameControllerThree controller;
    private int xCount;
    private int yCount;
    private int mineCount;
    private GamePanelThree gamePanel;
    private Player p1;
    private Player p2;
    private Player p3;

    public MainFrameThree(int m) {
        //todo: change the count of xCount, yCount and mineCount by passing parameters from constructor
        this.mineCount = m;

        if (mineCount == 10) {
            this.xCount = 9;//grid of row
            this.yCount = 9;// grid of column
        }

        if (mineCount == 40){
            this.xCount = 16;
            this.yCount = 16;
        }

        if (mineCount == 99){
            this.xCount = 16;
            this.yCount = 30;
        }

        this.setTitle("扫雷");
        this.setLayout(null);
        this.setSize(yCount * GirdComponentThree.gridSize + 20, xCount * GirdComponentThree.gridSize + 200);
        this.setLocationRelativeTo(null);


        Player p1 = new Player();
        Player p2 = new Player();
        Player p3= new Player();

        controller = new GameControllerThree(p1, p2, p3);
        GamePanelThree gamePanel = new GamePanelThree(xCount, yCount, mineCount);
        controller.setGamePanel(gamePanel);
        ScoreBoardThree scoreBoard = new ScoreBoardThree(p1, p2, p3, xCount, yCount);
        controller.setScoreBoard(scoreBoard);
        this.gamePanel = gamePanel;
        this.add(gamePanel);

        this.add(scoreBoard);


        // Change "click" to "Save".
        JButton cheat = new JButton("cheat");
        cheat.setSize(80, 20);
        cheat.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight());
        add(cheat);
        cheat.addActionListener(e -> {
            boolean cheatOrNot = false;
            for (int i = 0; i < xCount; i++) {
                for (int j = 0; j < yCount; j++) {
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                        cheatOrNot = true;
                    }
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CoveredWithMine)) {
                        gamePanel.mineField[i][j].setStatus(GridStatus.CheatOnMine);
                        gamePanel.repaint();
                    }
                }
            }
            if (cheatOrNot) {
                for (int i = 0; i < xCount; i++) {
                    for (int j = 0; j < yCount; j++) {

                        if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                            gamePanel.mineField[i][j].setStatus(GridStatus.CoveredWithMine);
                            gamePanel.repaint();
                        }
                    }
                }
            }
        });
        // Change "click" to "Save".
        JButton clickBtn = new JButton("Save");
        clickBtn.setSize(80, 20);
        clickBtn.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight());
        add(clickBtn);
        clickBtn.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            SaveForDataThree saveForData = new SaveForDataThree(this);
            controller.saveDataToFile(fileName + "basicData", saveForData.turnStringForBasic());
            controller.saveDataToFile(fileName + "grid", saveForData.turnStringForGrid());
            controller.saveDataToFile(fileName + "gridNum", saveForData.turnStringForGridNum());
            controller.saveDataToFile(fileName + "player", saveForData.turnStringForPlayers());
            System.out.println("fileName :" + fileName);

//            controller.readFileData(fileName);
//            controller.writeDataToFile(fileName);
        });

        JButton Read = new JButton("Read");
        Read.setSize(80, 20);
        Read.setLocation(200, gamePanel.getHeight() + scoreBoard.getHeight());
        add(Read);
        Read.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            System.out.println(controller.getDatafromFile(fileName + "basicData"));
//            System.out.println(controller.getDatafromFile(fileName+"grid"));
            System.out.println(controller.getDatafromFile(fileName + "gridNum"));
            ReadForDataThree readForData = new ReadForDataThree();
            System.out.println(controller.getDatafromFile(fileName + "player"));
            readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
            readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));
            readForData.readDataForGridNum(controller.getDatafromFile(fileName + "gridNum"));
            readForData.readDataForPlayer(controller.getDatafromFile(fileName + "player"));
            readForData.creatMainFrame();


        });

        JButton back = new JButton("back");
        back.setSize(80, 20);
        back.setLocation(300, gamePanel.getHeight() + scoreBoard.getHeight());
        add(back);
        back.addActionListener(e -> {


        });
        JButton check = new JButton("check");
        check.setSize(80, 20);
        check.setLocation(400, gamePanel.getHeight() + scoreBoard.getHeight());
        add(check);
        check.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            ReadForDataThree readForData = new ReadForDataThree();
            File file = new File("D:\\ideaproject\\MineSweeper-Demo\\src\\save" + fileName + "basicData" + ".json");
            if (file.exists()) {
                readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
                readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));

                if (readForData.checkForGrid()) {
                    System.out.println("是正确的存档");
                } else {
                    JFrame notTheSame = new JFrame();
                    this.setBounds(700, 400, 561, 486);
                    this.setResizable(false);

                    JLabel background = new JLabel("不是同一个存档");

                    notTheSame.add(background);

                    notTheSame.setVisible(true);

                }

            } else {
                System.out.println("无法找到该命名的存档");
            }
        });
    }
    public MainFrameThree(int m,Player p1,Player p2,Player p3) {
        //todo: change the count of xCount, yCount and mineCount by passing parameters from constructor
        this.mineCount = m;

        if (mineCount == 10) {
            this.xCount = 9;//grid of row
            this.yCount = 9;// grid of column
        }

        if (mineCount == 40){
            this.xCount = 16;
            this.yCount = 16;
        }

        if (mineCount == 99){
            this.xCount = 16;
            this.yCount = 30;
        }

        this.setTitle("扫雷");
        this.setLayout(null);
        this.setSize(yCount * GirdComponentThree.gridSize + 20, xCount * GirdComponentThree.gridSize + 200);
        this.setLocationRelativeTo(null);

        controller = new GameControllerThree(p1, p2, p3);
        GamePanelThree gamePanel = new GamePanelThree(xCount, yCount, mineCount);
        controller.setGamePanel(gamePanel);
        ScoreBoardThree scoreBoard = new ScoreBoardThree(p1, p2, p3, xCount, yCount);
        controller.setScoreBoard(scoreBoard);
        this.gamePanel = gamePanel;
        this.add(gamePanel);

        this.add(scoreBoard);


        // Change "click" to "Save".
        JButton cheat = new JButton("cheat");
        cheat.setSize(80, 20);
        cheat.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight());
        add(cheat);
        cheat.addActionListener(e -> {
            boolean cheatOrNot = false;
            for (int i = 0; i < xCount; i++) {
                for (int j = 0; j < yCount; j++) {
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                        cheatOrNot = true;
                    }
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CoveredWithMine)) {
                        gamePanel.mineField[i][j].setStatus(GridStatus.CheatOnMine);
                        gamePanel.repaint();
                    }
                }
            }
            if (cheatOrNot) {
                for (int i = 0; i < xCount; i++) {
                    for (int j = 0; j < yCount; j++) {

                        if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                            gamePanel.mineField[i][j].setStatus(GridStatus.CoveredWithMine);
                            gamePanel.repaint();
                        }
                    }
                }
            }
        });
        // Change "click" to "Save".
        JButton clickBtn = new JButton("Save");
        clickBtn.setSize(80, 20);
        clickBtn.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight());
        add(clickBtn);
        clickBtn.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            SaveForDataThree saveForData = new SaveForDataThree(this);
            controller.saveDataToFile(fileName + "basicData", saveForData.turnStringForBasic());
            controller.saveDataToFile(fileName + "grid", saveForData.turnStringForGrid());
            controller.saveDataToFile(fileName + "gridNum", saveForData.turnStringForGridNum());
            controller.saveDataToFile(fileName + "player", saveForData.turnStringForPlayers());
            System.out.println("fileName :" + fileName);

//            controller.readFileData(fileName);
//            controller.writeDataToFile(fileName);
        });

        JButton Read = new JButton("Read");
        Read.setSize(80, 20);
        Read.setLocation(200, gamePanel.getHeight() + scoreBoard.getHeight());
        add(Read);
        Read.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            System.out.println(controller.getDatafromFile(fileName + "basicData"));
//            System.out.println(controller.getDatafromFile(fileName+"grid"));
            System.out.println(controller.getDatafromFile(fileName + "gridNum"));
            ReadForDataThree readForData = new ReadForDataThree();
            readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
            readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));
            readForData.readDataForGridNum(controller.getDatafromFile(fileName + "gridNum"));
            readForData.readDataForPlayer(controller.getDatafromFile(fileName + "player"));
            System.out.println(controller.getDatafromFile(fileName + "player"));
            readForData.creatMainFrame();

        });

        JButton back = new JButton("back");
        back.setSize(80, 20);
        back.setLocation(300, gamePanel.getHeight() + scoreBoard.getHeight());
        add(back);
        back.addActionListener(e -> {


        });
        JButton check = new JButton("check");
        check.setSize(80, 20);
        check.setLocation(400, gamePanel.getHeight() + scoreBoard.getHeight());
        add(check);
        check.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            ReadForDataThree readForData = new ReadForDataThree();
            File file = new File("D:\\ideaproject\\MineSweeper-Demo\\src\\save" + fileName + "basicData" + ".json");
            if (file.exists()) {
                readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
                readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));

                if (readForData.checkForGrid()) {
                    System.out.println("是正确的存档");
                } else {
                    JFrame notTheSame = new JFrame();
                    this.setBounds(700, 400, 561, 486);
                    this.setResizable(false);

                    JLabel background = new JLabel("不是同一个存档");

                    notTheSame.add(background);

                    notTheSame.setVisible(true);

                }

            } else {
                System.out.println("无法找到该命名的存档");
            }
        });
    }

    public int getxCount() {
        return xCount;
    }

    public int getyCount() {
        return yCount;
    }

    public GamePanelThree getGamePanel() {
        return gamePanel;
    }

    public int getMineCount() {
        return mineCount;
    }

    public void setPlayer(Player[] playersHere) {
        this.p1 = playersHere[0];
        this.p2 = playersHere[1];
        this.p3 = playersHere[2];

    }


}