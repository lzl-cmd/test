package minesweeper;

import components.GirdComponentTwo;
import components.GridComponent;
import controller.GameController;
import entity.GridStatus;
import entity.Player;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.io.File;

public class MainFrame extends JFrame {
    public static GameController controller;
    private int xCount;
    private int yCount;
    private int mineCount;
    private GamePanel gamePanel;
    private Player p1;

    public MainFrame(int m) {
        //todo: change the count of xCount, yCount and mineCount by passing parameters from constructor
        this.mineCount = m;

        if (mineCount == 10) {
            this.xCount = 9;//grid of row
            this.yCount = 9;// grid of column
        }

        if (mineCount == 40) {
            this.xCount = 16;
            this.yCount = 16;
        }

        if (mineCount == 99) {
            this.xCount = 16;
            this.yCount = 30;
        }


        this.setTitle("扫雷");
        this.setLayout(null);
        this.setSize(yCount * GridComponent.gridSize + 20, xCount * GridComponent.gridSize + 200);
        this.setLocationRelativeTo(null);

        Player p1 = new Player();
        Player p2 = new Player();
        this.p1 = p1;
        controller = new GameController(p1, p2);
        GamePanel gamePanel = new GamePanel(xCount, yCount, mineCount);
        controller.setGamePanel(gamePanel);
        ScoreBoard scoreBoard = new ScoreBoard(p1, p2, xCount, yCount);
        controller.setScoreBoard(scoreBoard);
        this.gamePanel = gamePanel;

        this.add(gamePanel);

        //this.add(scoreBoard);


        // Change "click" to "Save".
        JButton cheat = new JButton("cheat");
        cheat.setSize(80, 20);
        cheat.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight());
        add(cheat);
        cheat.addActionListener(e -> {
            boolean cheatOrNot = false;
            for (int i = 0; i < xCount; i++) {
                for (int j = 0; j < yCount; j++) {
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                        cheatOrNot = true;
                    }
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CoveredWithMine)) {
                        gamePanel.mineField[i][j].setStatus(GridStatus.CheatOnMine);
                        gamePanel.repaint();
                    }
                }
            }
            if (cheatOrNot) {
                for (int i = 0; i < xCount; i++) {
                    for (int j = 0; j < yCount; j++) {

                        if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                            gamePanel.mineField[i][j].setStatus(GridStatus.CoveredWithMine);
                            gamePanel.repaint();
                        }
                    }
                }
            }
        });
        // Change "click" to "Save".
        JButton clickBtn = new JButton("Save");
        clickBtn.setSize(80, 20);
        clickBtn.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight());
        add(clickBtn);
        clickBtn.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            SaveForData saveForData = new SaveForData(this);
            controller.saveDataToFile(fileName + "basicData", saveForData.turnStringForBasic());
            controller.saveDataToFile(fileName + "grid", saveForData.turnStringForGrid());
            controller.saveDataToFile(fileName + "gridNum", saveForData.turnStringForGridNum());
//            controller.saveDataToFile(fileName + "player", saveForData.turnStringForPlayers());
            System.out.println("fileName :" + fileName);

//            controller.readFileData(fileName);
//            controller.writeDataToFile(fileName);
        });

        JButton Read = new JButton("Read");
        Read.setSize(80, 20);
        Read.setLocation(200, gamePanel.getHeight() + scoreBoard.getHeight());
        add(Read);
        Read.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            System.out.println(controller.getDatafromFile(fileName + "basicData"));
//            System.out.println(controller.getDatafromFile(fileName+"grid"));
            System.out.println(controller.getDatafromFile(fileName + "gridNum"));
            ReadForData readForData = new ReadForData();
            readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
            readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));
            readForData.readDataForGridNum(controller.getDatafromFile(fileName + "gridNum"));
//            readForData.readDataForPlayer(controller.getDatafromFile(fileName + "player"));
            readForData.creatMainFrame();


        });

        /*JButton back = new JButton("back");
        back.setSize(80, 20);
        back.setLocation(300, gamePanel.getHeight() + scoreBoard.getHeight());
        add(back);
        back.addActionListener(e -> {


        });

         */

        JButton restart = new JButton("restart");
        restart.setSize(80, 20);
        restart.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight()+40);
        add(restart);
        restart.addActionListener(e -> {
            this.setVisible(false);
            MainFrame mainFrame = new MainFrame(m);
            mainFrame.setVisible(true);
        });

        JButton check = new JButton("check");
        check.setSize(80, 20);
        check.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight()+40);
        add(check);
        check.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            ReadForData readForData = new ReadForData();
            File file = new File("D:\\ideaproject\\MineSweeper-Demo\\src\\save" + fileName + "basicData" + ".json");
            if (file.exists()) {
                readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
                readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));

                if (readForData.checkForGrid()) {
                    JFrame same = new JFrame();
                    same.setBounds(700, 400, 500, 364);
                    same.setResizable(false);
                    same.setTitle("是正确的存档");

                    JLabel background = new JLabel();
                    background.setBounds(0,0,500,364);
                    background.setIcon(Data.yes);

                    same.add(background);
                    same.setVisible(true);
                } else {
                    JFrame notTheSame = new JFrame();
                    notTheSame.setBounds(700, 400, 500, 375);
                    notTheSame.setResizable(false);
                    notTheSame.setTitle("不是同一个存档");

                    JLabel background = new JLabel();
                    background.setBounds(0,0,500,375);
                    background.setIcon(Data.fail);

                    notTheSame.add(background);

                    notTheSame.setVisible(true);
                }

            } else {
                JFrame empty = new JFrame();
                empty.setBounds(700, 400, 500, 375);
                empty.setResizable(false);
                empty.setTitle("无法找到该命名的存档");

                JLabel background = new JLabel();
                background.setBounds(0,0,500,375);
                background.setIcon(Data.fail);

                empty.add(background);

                empty.setVisible(true);
            }
        });
    }

    public MainFrame(int x, int y, int z){
        this.xCount = x;
        this.yCount = y;
        this.mineCount = z;

        this.setTitle("扫雷");
        this.setLayout(null);
        this.setSize(yCount * GirdComponentTwo.gridSize + 20, xCount * GirdComponentTwo.gridSize + 200);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        Player p1 = new Player();
        Player p2 = new Player();



        controller = new GameController(p1, p2);

        GamePanel gamePanel = new GamePanel(xCount, yCount, mineCount);
        controller.setGamePanel(gamePanel);
        ScoreBoard scoreBoard = new ScoreBoard(p1, p2, xCount, yCount);
        controller.setScoreBoard(scoreBoard);
        this.gamePanel = gamePanel;

        this.add(gamePanel);


        JButton cheat = new JButton("cheat");
        cheat.setSize(80, 20);
        cheat.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight());
        add(cheat);
        cheat.addActionListener(e -> {
            boolean cheatOrNot = false;
            for (int i = 0; i < xCount; i++) {
                for (int j = 0; j < yCount; j++) {
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                        cheatOrNot = true;
                    }
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CoveredWithMine)) {
                        gamePanel.mineField[i][j].setStatus(GridStatus.CheatOnMine);
                        gamePanel.repaint();
                    }
                }
            }
            if (cheatOrNot) {
                for (int i = 0; i < xCount; i++) {
                    for (int j = 0; j < yCount; j++) {

                        if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                            gamePanel.mineField[i][j].setStatus(GridStatus.CoveredWithMine);
                            gamePanel.repaint();
                        }
                    }
                }
            }
        });

        // Change "click" to "Save".

        JButton clickBtn = new JButton("Save");
        clickBtn.setSize(80, 20);
        clickBtn.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight());
        add(clickBtn);
        clickBtn.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            SaveForData saveForData = new SaveForData(this);
            controller.saveDataToFile(fileName + "basicData", saveForData.turnStringForBasic());
            controller.saveDataToFile(fileName + "grid", saveForData.turnStringForGrid());
            controller.saveDataToFile(fileName + "gridNum", saveForData.turnStringForGridNum());
//            controller.saveDataToFile(fileName + "player", saveForData.turnStringForPlayers());
            System.out.println("fileName :" + fileName);

//            controller.readFileData(fileName);
//            controller.writeDataToFile(fileName);
        });

        JButton Read = new JButton("Read");
        Read.setSize(80, 20);
        Read.setLocation(200, gamePanel.getHeight() + scoreBoard.getHeight());
        add(Read);
        Read.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            System.out.println(controller.getDatafromFile(fileName + "basicData"));
//            System.out.println(controller.getDatafromFile(fileName+"grid"));
            System.out.println(controller.getDatafromFile(fileName + "gridNum"));
            ReadForData readForData = new ReadForData();
            readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
            readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));
            readForData.readDataForGridNum(controller.getDatafromFile(fileName + "gridNum"));
//            readForData.readDataForPlayer(controller.getDatafromFile(fileName + "player"));
            System.out.println(controller.getDatafromFile(fileName + "player"));
            readForData.creatMainFrame();


        });

        JButton restart = new JButton("restart");
        restart.setSize(80, 20);
        restart.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight()+40);
        add(restart);
        restart.addActionListener(e -> {
            this.setVisible(false);
            MainFrame mainFrame = new MainFrame(x, y, z);
            mainFrame.setVisible(true);

        });


        JButton check = new JButton("check");
        check.setSize(80, 20);
        check.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight()+40);
        add(check);
        check.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            ReadForDataTwo readForData = new ReadForDataTwo();
            File file = new File("save" + fileName + "basicData" + ".json");
            if (file.exists()) {
                readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
                readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));

                if (readForData.checkForGrid()) {
                    JFrame same = new JFrame();
                    same.setBounds(700, 400, 500, 364);
                    same.setResizable(false);
                    same.setTitle("是正确的存档");

                    JLabel background = new JLabel();
                    background.setBounds(0,0,500,364);
                    background.setIcon(Data.yes);

                    same.add(background);
                    same.setVisible(true);
                } else {
                    JFrame notTheSame = new JFrame();
                    notTheSame.setBounds(700, 400, 500, 375);
                    notTheSame.setResizable(false);
                    notTheSame.setTitle("不是同一个存档");

                    JLabel background = new JLabel();
                    background.setBounds(0,0,500,375);
                    background.setIcon(Data.fail);

                    notTheSame.add(background);

                    notTheSame.setVisible(true);
                }

            } else {
                JFrame empty = new JFrame();
                empty.setBounds(700, 400, 500, 375);
                empty.setResizable(false);
                empty.setTitle("无法找到该命名的存档");

                JLabel background = new JLabel();
                background.setBounds(0,0,500,375);
                background.setIcon(Data.fail);

                empty.add(background);

                empty.setVisible(true);
            }
        });
    }

    public int getxCount() {
        return xCount;
    }

    public int getyCount() {
        return yCount;
    }

    public GamePanel getGamePanel() {
        return gamePanel;
    }

    public int getMineCount() {
        return mineCount;
    }
    public void setPlayer(Player player){
        this.p1 = player;
    }

}