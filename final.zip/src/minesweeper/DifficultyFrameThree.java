package minesweeper;


import javax.swing.*;
import java.awt.*;

public class DifficultyFrameThree extends JFrame {
    private JComboBox<String> difficulty;
    private JLabel label;
    private static final int DEFAULT_SIZE = 27;

    public DifficultyFrameThree() {
        label = new JLabel("难度");
        label.setFont(new Font("", Font.ITALIC, DEFAULT_SIZE));
        //add(label, BorderLayout.CENTER);
        label.setIcon(Data.difficulty1);
        //label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setLocation(5,5);

        Container container = getContentPane();
        container.add(label);
        container.setBackground(new Color(140, 241, 223));




        difficulty = new JComboBox<>();
        difficulty.addItem("简单");
        difficulty.addItem("中等");
        difficulty.addItem("困难");
        difficulty.addItem("自定义");

        difficulty.addActionListener(event -> {
                    switch (difficulty.getSelectedIndex()) {
                        case 0: {
                            MainFrameThree mainFrameThree = new MainFrameThree(10);
                            mainFrameThree.setVisible(true);
                            break;
                        }
                        case 1: {
                            MainFrameThree mainFrameThree = new MainFrameThree(40);
                            mainFrameThree.setVisible(true);
                            break;
                        }
                        case 2: {
                            MainFrameThree mainFrameThree = new MainFrameThree(99);
                            mainFrameThree.setVisible(true);
                            break;

                        }
                        case 3: {
                            SetFrameThree setFrameThree = new SetFrameThree();
                            setFrameThree.setVisible(false);

                        }

                    }

                }
        );
        JPanel comboPanel = new JPanel();
        comboPanel.add(difficulty);
        comboPanel.setBackground(new Color(140, 241, 223));
        add(comboPanel, BorderLayout.SOUTH);
        pack();
        this.setTitle("扫雷");
        this.setLayout(null);
        this.setBounds(300,100,380,260);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
    }


}
