package minesweeper;

import javax.swing.*;
import java.awt.*;

public class WelcomeFrame1 extends JFrame {

    public WelcomeFrame1(){
        this.setBounds(750,150,450,800);
        this.setResizable(false);
        this.setTitle("扫雷");
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        WelcomePanel panel = new WelcomePanel();
        this.add(panel);
        this.setVisible(true);

        JPanel jp = new JPanel();
        jp.setLayout(null);

        JButton onebutton = new JButton();
        jp.setOpaque(false);
        onebutton.setBounds(70,610,78,107);
        onebutton.setBackground(new Color(208, 227, 25, 252));
        onebutton.setIcon(Data.one);
        onebutton.setToolTipText("单人模式");
        onebutton.addActionListener(new MyActionListener01());


        JButton twobutton = new JButton();
        jp.setOpaque(false);
        twobutton.setBounds(200,610,180,107);
        twobutton.setBackground(new Color(174, 52, 222, 252));
        twobutton.setIcon(Data.two);
        twobutton.setToolTipText("双人模式");
        twobutton.addActionListener(new MyActionListener02());

        JButton threeButton = new JButton();
        jp.setOpaque(false);
        threeButton.setBounds(80,5,68,107);
        threeButton.setBackground(new Color(11, 14, 167));
        threeButton.setIcon(Data.three);
        threeButton.addActionListener(new MyActionListener04());

        JButton changeButton1 = new JButton();
        jp.setOpaque(false);
        changeButton1.setBounds(155,5,68,107);
        changeButton1.setBackground(new Color(227, 74, 117));
        changeButton1.setIcon(Data.change);
        changeButton1.addActionListener(new MyActionListener06());


        JButton ruleButton = new JButton();
        jp.setOpaque(false);
        ruleButton.setBounds(5,5,68,107);
        ruleButton.setBackground(new Color(224, 90, 27));
        ruleButton.setIcon(Data.ruleButton);
        ruleButton.setToolTipText("游戏规则");
        ruleButton.addActionListener(new MyActionListener03());


        jp.add(onebutton);
        jp.add(twobutton);
        jp.add(ruleButton);
        jp.add(threeButton);
        jp.add(changeButton1);
        this.add(jp);



    }

}

