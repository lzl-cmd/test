package minesweeper;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class WelcomePanel extends JPanel {

    public WelcomePanel(){
        JPanel jp = new JPanel();
        jp.setLayout(null);

        JButton onebutton = new JButton();
        jp.setOpaque(false);
        onebutton.setBounds(70,610,78,107);
        onebutton.setBackground(new Color(105, 212, 193, 252));
        onebutton.setIcon(Data.one);
        onebutton.setToolTipText("单人模式");
        onebutton.addActionListener(new MyActionListener01());


        JButton twobutton = new JButton();
        jp.setOpaque(false);
        twobutton.setBounds(200,610,180,107);
        twobutton.setBackground(new Color(105, 212, 208, 252));
        twobutton.setIcon(Data.two);
        twobutton.setToolTipText("双人模式");
        twobutton.addActionListener(new MyActionListener02());

        JButton threeButton = new JButton();
        jp.setOpaque(false);
        threeButton.setBounds(80,5,68,107);
        threeButton.setBackground(new Color(11, 142, 167));
        threeButton.setIcon(Data.three);
        threeButton.addActionListener(new MyActionListener04());


        JButton ruleButton = new JButton();
        jp.setOpaque(false);
        ruleButton.setBounds(5,5,68,107);
        ruleButton.setBackground(new Color(11, 142, 167));
        ruleButton.setIcon(Data.ruleButton);
        ruleButton.setToolTipText("游戏规则");
        ruleButton.addActionListener(new MyActionListener03());

        JButton changeButton = new JButton();
        jp.setOpaque(false);
        changeButton.setBounds(155,5,68,107);
        changeButton.setBackground(new Color(11, 142, 167));
        changeButton.setIcon(Data.change);
        changeButton.addActionListener(new MyActionListener05());


        jp.add(onebutton);
        jp.add(twobutton);
        jp.add(ruleButton);
        jp.add(threeButton);
        jp.add(changeButton);


    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        this.setBackground(Color.BLACK);
        Data.start.paintIcon(this,g,0,0);
        Data.oneText.paintIcon(this,g,50,560);
        Data.twoText.paintIcon(this,g,220,560);
        Data.title.paintIcon(this,g,300,50);


    }

}

class MyActionListener01 implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent e) {
        DifficultyFrame difficultyFrame = new DifficultyFrame();
        difficultyFrame.setVisible(true);
        System.out.println("one");


    }
}

class MyActionListener02 implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) {
        DifficultyFrameTwo difficultyFrameTwo = new DifficultyFrameTwo();
        difficultyFrameTwo.setVisible(true);
        System.out.println("two");
    }
}

class MyActionListener03 implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) {
        RuleFrame ruleFrame = new RuleFrame();
        ruleFrame.setVisible(true);
        System.out.println("rule");
    }
}

class MyActionListener04 implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) {
        DifficultyFrameThree difficultyFrameThree = new DifficultyFrameThree();
        difficultyFrameThree.setVisible(true);
        System.out.println("three");
    }
}

class MyActionListener05 implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) {
        WelcomeFrame1 welcomeFrame1 = new WelcomeFrame1();
        welcomeFrame1.setVisible(true);
    }
}

class MyActionListener06 implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) {
        WelcomeFrame welcomeFrame = new WelcomeFrame();
        welcomeFrame.setVisible(true);
    }
}


