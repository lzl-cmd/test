package minesweeper;

import components.GridComponent;
import controller.GameController;
import entity.GridStatus;
import entity.Player;

public class ReadForDataTwo {
    private String data;
    private String[] grid;
    private String[] basic;
    private String[][] grids;
    private String[] gridNum;
    private String[][] gridNums;
    private String[] players;
    private int playersNum;
    private Player player1;
    private Player player2;
    private Player[] playersHere;
    private String playerName1;
    private String playerName2;
    private String player1Score;
    private String player2Score;
    private String player1Mistake;
    private String player2Mistake;
    private int path;
    private int xCount;
    private int yCount;
    private int mineCount;
    private GridComponent[][] gridComponents;
    private MainFrame mainFrame;

    public ReadForDataTwo(){
        Player p1 = new Player();
        Player p2 = new Player();
        this.player1 = p1;
        this.player2 = p2;
        this.playersHere = new Player[2];

    }
    public void initGridComponent(){
        for (int i = 0; i < xCount; i++) {
            for (int j = 0; j < yCount; j++) {
                GridComponent gridComponent = new GridComponent(i, j, xCount, yCount);
                gridComponents[i][j] = gridComponent;
            }
        }
    }
    public void getBasic(String str) {
        this.basic = str.split(" ");
    }
    public void getGrid(String str) {
        this.grid = str.split(" ");
    }
    public void getGridNum(String str) {
        this.gridNum = str.split(" ");
    }
    public void getPlayer(String str){
        this.players = str.split(" ");
    }

    public void readDataForBasic(String str) {
        getBasic(str);
        this.xCount = Integer.parseInt(this.basic[0]);
        this.yCount = Integer.parseInt(this.basic[1]);
        this.mineCount = Integer.parseInt(this.basic[2]);
        this.playersNum = Integer.parseInt(this.basic[3]);
        this.gridComponents = new GridComponent[xCount][yCount];
        this.grids = new String[xCount][yCount];
        this.gridNums = new String[xCount][yCount];
        this.players = new String[playersNum];
    }
    public void readDataForBasicAno(String str) {
        getBasic(str);
        this.xCount = Integer.parseInt(this.basic[0]);
        this.yCount = Integer.parseInt(this.basic[1]);
        this.mineCount = Integer.parseInt(this.basic[2]);
        this.playersNum = Integer.parseInt(this.basic[3]);
        this.path = Integer.parseInt(this.basic[4]);
        this.gridComponents = new GridComponent[xCount][yCount];
        this.grids = new String[xCount][yCount];
        this.gridNums = new String[xCount][yCount];
        this.players = new String[playersNum];

    }

    public void readDataForGrid(String str){
        getGrid(str);
        one2Two(grid,grids);
        initGridComponent();
        for (int i = 0; i < xCount; i++) {
            for (int j = 0; j < yCount; j++) {
                gridComponents[i][j].setStatus(Enum.valueOf(GridStatus.class,grids[i][j]));
            }
        }
    }
    public void readDataForGridNum(String str) {
        getGridNum(str);
        one2Two(gridNum,gridNums);
        for (int i = 0; i < xCount; i++) {
            for (int j = 0; j < yCount; j++) {
                gridComponents[i][j].setContent(Integer.parseInt(gridNums[i][j]));
            }
        }
    }
    public void readDataForPlayer(String str){
        getPlayer(str);
        playerName1 = players[0];
        player1Score = players[1];
        player1Mistake = players[2];
        playerName2 = players[3];
        player2Score = players[4];
        player2Mistake = players[5];
        player1.setUserName(playerName1);
        player2.setUserName(playerName2);
        player1.setScore(Integer.parseInt(player1Score));
        player2.setScore(Integer.parseInt(player2Score));
        player1.setMistake(Integer.parseInt(player1Mistake));
        player2.setMistake(Integer.parseInt(player2Mistake));
        playersHere[0] = player1;
        playersHere[1] = player2;
    }
    public void readDataForPlayerAno(String str){
        getPlayer(str);
        playerName1 = players[0];
        player1Score = players[1];
        player1Mistake = players[2];
        playerName2 = players[3];
        player2Score = players[4];
        player2Mistake = players[5];
        player1.setUserName(playerName1);
        player2.setUserName(playerName2);
        player1.setScore(Integer.parseInt(player1Score));
        player2.setScore(Integer.parseInt(player2Score));
        player1.setMistake(Integer.parseInt(player1Mistake));
        player2.setMistake(Integer.parseInt(player2Mistake));
        playersHere[0] = player1;
        playersHere[1] = player2;
    }

    public boolean checkForGrid() {
        if (MainFrameTwo.controller.getGamePanel().getxCount() != this.xCount) {
            return false;
        }
        if (MainFrameTwo.controller.getGamePanel().getyCount() != this.yCount) {
            return false;
        }
        for (int i = 0; i < this.xCount; i++) {
            for (int j = 0; j < this.yCount; j++) {
                if(!this.gridComponents[i][j].getStatus().equals(MainFrameTwo.controller.getGamePanel().mineField[i][j].getStatus())){
                    return false;
                }
            }
        }
        return true;
    }


    public void creatMainFrame() {
        MainFrameTwo mainFrameSavedBefore = new MainFrameTwo(mineCount,player1,player2);
        for (int i = 0; i < xCount; i++) {
            for (int j = 0; j < yCount; j++) {
                mainFrameSavedBefore.getGamePanel().mineField[i][j].setStatus(this.gridComponents[i][j].getStatus());
                mainFrameSavedBefore.getGamePanel().mineField[i][j].setContent(this.gridComponents[i][j].getContent());
                mainFrameSavedBefore.getGamePanel().setChessboard(this.gridComponents[i][j].getContent(),i,j);
            }
        }
        mainFrameSavedBefore.setVisible(true);
    }
    public void creatMainFrameAno() {
        MainFrameTwo mainFrameSavedBefore = new MainFrameTwo(xCount,yCount,mineCount,path,player1,player2);
        for (int i = 0; i < xCount; i++) {
            for (int j = 0; j < yCount; j++) {
                mainFrameSavedBefore.getGamePanel().mineField[i][j].setStatus(this.gridComponents[i][j].getStatus());
                mainFrameSavedBefore.getGamePanel().mineField[i][j].setContent(this.gridComponents[i][j].getContent());
                mainFrameSavedBefore.getGamePanel().setChessboard(this.gridComponents[i][j].getContent(),i,j);
            }
        }
        mainFrameSavedBefore.setVisible(true);
    }


    public static void one2Two(String[] first, String[][] take) {
        int z = 0;
        int length = take.length;
        int lie = take[0].length;
        for (int i = 0; i < length; i++) {
            for (int j = 0; j < lie; j++) {
                take[i][j] = first[z];
                z++;
            }
        }
    }


}
