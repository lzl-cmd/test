package minesweeper;

import javax.swing.*;
import java.awt.*;

public class WinFrame extends JFrame {

    public WinFrame(){

        this.setTitle("你赢了");
        this.setVisible(true);
        this.setLayout(null);
        this.setBounds(700,400,525,507);
        this.setResizable(false);

        JLabel background = new JLabel();
        background.setBounds(0,0,525,507);
        background.setIcon(Data.win);

        Container container = getContentPane();
        container.add(background);

        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

    }
}

