package minesweeper;

import components.GirdComponentThree;
import components.GirdComponentTwo;
import controller.GameController;
import controller.GameControllerThree;
import entity.GridStatus;
import entity.Player;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.io.File;

public class MainFrameThree extends JFrame {
    public static GameControllerThree controller;
    private int xCount;
    private int yCount;
    private int mineCount;
    private GamePanelThree gamePanel;
    private Player p1;
    private Player p2;
    private Player p3;

    public MainFrameThree(int m) {
        //todo: change the count of xCount, yCount and mineCount by passing parameters from constructor
        this.mineCount = m;

        if (mineCount == 10) {
            this.xCount = 9;//grid of row
            this.yCount = 9;// grid of column
        }

        if (mineCount == 40){
            this.xCount = 16;
            this.yCount = 16;
        }

        if (mineCount == 99){
            this.xCount = 16;
            this.yCount = 30;
        }

        this.setTitle("扫雷");
        this.setLayout(null);
        this.setSize(yCount * GirdComponentThree.gridSize + 20, xCount * GirdComponentThree.gridSize + 300);
        this.setLocationRelativeTo(null);


        Player p1 = new Player();
        Player p2 = new Player();
        Player p3 = new Player();

        String name1 = JOptionPane.showInputDialog(this, "玩家1名字");
        System.out.println("p1 :"+name1);
        String name2 = JOptionPane.showInputDialog(this, "玩家2名字");
        System.out.println("p2 :"+name2);
        String name3 = JOptionPane.showInputDialog(this, "玩家3名字");
        System.out.println("p3 :"+name3);

        controller = new GameControllerThree(p1, p2, p3);
        MainFrameThree.controller.getP1().setUserName(name1);
        MainFrameThree.controller.getP2().setUserName(name2);
        MainFrameThree.controller.getP3().setUserName(name3);
        GamePanelThree gamePanel = new GamePanelThree(xCount, yCount, mineCount);
        controller.setGamePanel(gamePanel);
        ScoreBoardThree scoreBoard = new ScoreBoardThree(p1, p2, p3, xCount, yCount);
        controller.setScoreBoard(scoreBoard);
        this.gamePanel = gamePanel;
        this.add(gamePanel);

        this.add(scoreBoard);


        // Change "click" to "Save".
        JButton cheat = new JButton("cheat");
        cheat.setSize(80, 20);
        cheat.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight());
        add(cheat);
        cheat.addActionListener(e -> {
            boolean cheatOrNot = false;
            for (int i = 0; i < xCount; i++) {
                for (int j = 0; j < yCount; j++) {
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                        cheatOrNot = true;
                    }
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CoveredWithMine)) {
                        gamePanel.mineField[i][j].setStatus(GridStatus.CheatOnMine);
                        gamePanel.repaint();
                    }
                }
            }
            if (cheatOrNot) {
                for (int i = 0; i < xCount; i++) {
                    for (int j = 0; j < yCount; j++) {

                        if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                            gamePanel.mineField[i][j].setStatus(GridStatus.CoveredWithMine);
                            gamePanel.repaint();
                        }
                    }
                }
            }
        });
        // Change "click" to "Save".
        JButton clickBtn = new JButton("Save");
        clickBtn.setSize(80, 20);
        clickBtn.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight());
        add(clickBtn);
        clickBtn.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");

            SaveForDataThree saveForData = new SaveForDataThree(this);
            controller.saveDataToFile(fileName + "basicData", saveForData.turnStringForBasic());
            controller.saveDataToFile(fileName + "grid", saveForData.turnStringForGrid());
            controller.saveDataToFile(fileName + "gridNum", saveForData.turnStringForGridNum());
            controller.saveDataToFile(fileName + "player", saveForData.turnStringForPlayers());
            System.out.println("fileName :" + fileName);

//            controller.readFileData(fileName);
//            controller.writeDataToFile(fileName);
        });

        JButton Read = new JButton("Read");
        Read.setSize(80, 20);
        Read.setLocation(200, gamePanel.getHeight() + scoreBoard.getHeight());
        add(Read);
        Read.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            System.out.println(controller.getDatafromFile(fileName + "basicData"));
//            System.out.println(controller.getDatafromFile(fileName+"grid"));
            System.out.println(controller.getDatafromFile(fileName + "gridNum"));
            ReadForDataThree readForData = new ReadForDataThree();
            System.out.println(controller.getDatafromFile(fileName + "player"));
            readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
            readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));
            readForData.readDataForGridNum(controller.getDatafromFile(fileName + "gridNum"));
            readForData.readDataForPlayer(controller.getDatafromFile(fileName + "player"));
            readForData.creatMainFrame();


        });

        JButton restart = new JButton("restart");
        restart.setSize(80, 20);
        restart.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight()+40);
        add(restart);
        restart.addActionListener(e -> {
            this.setVisible(false);
            MainFrameThree mainFrameThree = new MainFrameThree(m);
            mainFrameThree.setVisible(true);

        });

        JButton check = new JButton("check");
        check.setSize(80, 20);
        check.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight()+40);
        add(check);
        check.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            ReadForDataThree readForData = new ReadForDataThree();
            File file = new File("D:\\ideaproject\\project4\\projectdemo\\src\\save\\" + fileName + "basicData" + ".json");
            if (file.exists()) {
                readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
                readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));

                if (readForData.checkForGrid()) {
                    JFrame same = new JFrame();
                    same.setBounds(700, 400, 500, 364);
                    same.setResizable(false);
                    same.setTitle("是正确的存档");

                    JLabel background = new JLabel();
                    background.setBounds(0,0,500,364);
                    background.setIcon(Data.yes);

                    same.add(background);
                    same.setVisible(true);
                } else {
                    JFrame notTheSame = new JFrame();
                    notTheSame.setBounds(700, 400, 500, 375);
                    notTheSame.setResizable(false);
                    notTheSame.setTitle("不是同一个存档");

                    JLabel background = new JLabel();
                    background.setBounds(0,0,500,375);
                    background.setIcon(Data.fail);

                    notTheSame.add(background);

                    notTheSame.setVisible(true);
                }

            } else {
                JFrame empty = new JFrame();
                empty.setBounds(700, 400, 500, 375);
                empty.setResizable(false);
                empty.setTitle("无法找到该命名的存档");

                JLabel background = new JLabel();
                background.setBounds(0,0,500,375);
                background.setIcon(Data.fail);

                empty.add(background);

                empty.setVisible(true);
            }
        });
    }
    public MainFrameThree(int m,Player p1,Player p2,Player p3) {
        //todo: change the count of xCount, yCount and mineCount by passing parameters from constructor
        this.mineCount = m;

        if (mineCount == 10) {
            this.xCount = 9;//grid of row
            this.yCount = 9;// grid of column
        }

        if (mineCount == 40){
            this.xCount = 16;
            this.yCount = 16;
        }

        if (mineCount == 99){
            this.xCount = 16;
            this.yCount = 30;
        }

        this.setTitle("扫雷");
        this.setLayout(null);
        this.setSize(yCount * GirdComponentThree.gridSize + 20, xCount * GirdComponentThree.gridSize + 300);
        this.setLocationRelativeTo(null);

        controller = new GameControllerThree(p1, p2, p3);
        GamePanelThree gamePanel = new GamePanelThree(xCount, yCount, mineCount);
        controller.setGamePanel(gamePanel);
        ScoreBoardThree scoreBoard = new ScoreBoardThree(p1, p2, p3, xCount, yCount);
        controller.setScoreBoard(scoreBoard);
        this.gamePanel = gamePanel;
        this.add(gamePanel);

        this.add(scoreBoard);


        // Change "click" to "Save".
        JButton cheat = new JButton("cheat");
        cheat.setSize(80, 20);
        cheat.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight());
        add(cheat);
        cheat.addActionListener(e -> {
            boolean cheatOrNot = false;
            for (int i = 0; i < xCount; i++) {
                for (int j = 0; j < yCount; j++) {
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                        cheatOrNot = true;
                    }
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CoveredWithMine)) {
                        gamePanel.mineField[i][j].setStatus(GridStatus.CheatOnMine);
                        gamePanel.repaint();
                    }
                }
            }
            if (cheatOrNot) {
                for (int i = 0; i < xCount; i++) {
                    for (int j = 0; j < yCount; j++) {

                        if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                            gamePanel.mineField[i][j].setStatus(GridStatus.CoveredWithMine);
                            gamePanel.repaint();
                        }
                    }
                }
            }
        });
        // Change "click" to "Save".
        JButton clickBtn = new JButton("Save");
        clickBtn.setSize(80, 20);
        clickBtn.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight());
        add(clickBtn);
        clickBtn.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            SaveForDataThree saveForData = new SaveForDataThree(this);
            controller.saveDataToFile(fileName + "basicData", saveForData.turnStringForBasic());
            controller.saveDataToFile(fileName + "grid", saveForData.turnStringForGrid());
            controller.saveDataToFile(fileName + "gridNum", saveForData.turnStringForGridNum());
            controller.saveDataToFile(fileName + "player", saveForData.turnStringForPlayers());
            System.out.println("fileName :" + fileName);

//            controller.readFileData(fileName);
//            controller.writeDataToFile(fileName);
        });

        JButton Read = new JButton("Read");
        Read.setSize(80, 20);
        Read.setLocation(200, gamePanel.getHeight() + scoreBoard.getHeight());
        add(Read);
        Read.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            System.out.println(controller.getDatafromFile(fileName + "basicData"));
//            System.out.println(controller.getDatafromFile(fileName+"grid"));
            System.out.println(controller.getDatafromFile(fileName + "gridNum"));
            ReadForDataThree readForData = new ReadForDataThree();
            readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
            readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));
            readForData.readDataForGridNum(controller.getDatafromFile(fileName + "gridNum"));
            readForData.readDataForPlayer(controller.getDatafromFile(fileName + "player"));
            System.out.println(controller.getDatafromFile(fileName + "player"));
            readForData.creatMainFrame();

        });

        JButton restart = new JButton("restart");
        restart.setSize(80, 20);
        restart.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight()+40);
        add(restart);
        restart.addActionListener(e -> {
            this.setVisible(false);
            MainFrameThree mainFrameThree = new MainFrameThree(m, p1, p2, p3);
            mainFrameThree.setVisible(true);

        });

        JButton check = new JButton("check");
        check.setSize(80, 20);
        check.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight()+40);
        add(check);
        check.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            ReadForDataThree readForData = new ReadForDataThree();
            File file = new File("D:\\ideaproject\\project4\\projectdemo\\src\\save\\" + fileName + "basicData" + ".json");
            if (file.exists()) {
                readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
                readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));

                if (readForData.checkForGrid()) {
                    JFrame same = new JFrame();
                    same.setBounds(700, 400, 500, 364);
                    same.setResizable(false);
                    same.setTitle("是正确的存档");

                    JLabel background = new JLabel();
                    background.setBounds(0,0,500,364);
                    background.setIcon(Data.yes);

                    same.add(background);
                    same.setVisible(true);
                } else {
                    JFrame notTheSame = new JFrame();
                    notTheSame.setBounds(700, 400, 500, 375);
                    notTheSame.setResizable(false);
                    notTheSame.setTitle("不是同一个存档");

                    JLabel background = new JLabel();
                    background.setBounds(0,0,500,375);
                    background.setIcon(Data.fail);

                    notTheSame.add(background);

                    notTheSame.setVisible(true);
                }

            } else {
                JFrame empty = new JFrame();
                empty.setBounds(700, 400, 500, 375);
                empty.setResizable(false);
                empty.setTitle("无法找到该命名的存档");

                JLabel background = new JLabel();
                background.setBounds(0,0,500,375);
                background.setIcon(Data.fail);

                empty.add(background);

                empty.setVisible(true);
            }
        });
    }

    public MainFrameThree(int x, int y, int z){
        this.xCount = x;
        this.yCount = y;
        this.mineCount = z;

        this.setTitle("扫雷");
        this.setLayout(null);
        this.setSize(yCount * GirdComponentTwo.gridSize + 20, xCount * GirdComponentTwo.gridSize + 300);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        Player p1 = new Player();
        Player p2 = new Player();
        Player p3 = new Player();

        String name1 = JOptionPane.showInputDialog(this, "玩家1名字");
        System.out.println("p1 :"+name1);
        String name2 = JOptionPane.showInputDialog(this, "玩家2名字");
        System.out.println("p2 :"+name2);
        String name3 = JOptionPane.showInputDialog(this, "玩家3名字");
        System.out.println("p3 :"+name2);

        controller = new GameControllerThree(p1, p2, p3);
        MainFrameThree.controller.getP1().setUserName(name1);
        MainFrameThree.controller.getP2().setUserName(name2);
        MainFrameThree.controller.getP3().setUserName(name3);
        GamePanelThree gamePanel = new GamePanelThree(xCount, yCount, mineCount);
        controller.setGamePanel(gamePanel);
        ScoreBoardThree scoreBoardThree = new ScoreBoardThree(p1, p2, p3, xCount, yCount);
        controller.setScoreBoard(scoreBoardThree);
        this.gamePanel = gamePanel;

        this.add(gamePanel);
        this.add(scoreBoardThree);

        JButton cheat = new JButton("cheat");
        cheat.setSize(80, 20);
        cheat.setLocation(100, gamePanel.getHeight() + scoreBoardThree.getHeight());
        add(cheat);
        cheat.addActionListener(e -> {
            boolean cheatOrNot = false;
            for (int i = 0; i < xCount; i++) {
                for (int j = 0; j < yCount; j++) {
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                        cheatOrNot = true;
                    }
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CoveredWithMine)) {
                        gamePanel.mineField[i][j].setStatus(GridStatus.CheatOnMine);
                        gamePanel.repaint();
                    }
                }
            }
            if (cheatOrNot) {
                for (int i = 0; i < xCount; i++) {
                    for (int j = 0; j < yCount; j++) {

                        if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                            gamePanel.mineField[i][j].setStatus(GridStatus.CoveredWithMine);
                            gamePanel.repaint();
                        }
                    }
                }
            }
        });

        // Change "click" to "Save".

        JButton clickBtn = new JButton("Save");
        clickBtn.setSize(80, 20);
        clickBtn.setLocation(5, gamePanel.getHeight() + scoreBoardThree.getHeight());
        add(clickBtn);
        clickBtn.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            SaveForDataThree saveForData = new SaveForDataThree(this);
            controller.saveDataToFile(fileName + "basicData", saveForData.turnStringForBasic());
            controller.saveDataToFile(fileName + "grid", saveForData.turnStringForGrid());
            controller.saveDataToFile(fileName + "gridNum", saveForData.turnStringForGridNum());
            controller.saveDataToFile(fileName + "player", saveForData.turnStringForPlayers());
            System.out.println("fileName :" + fileName);

//            controller.readFileData(fileName);
//            controller.writeDataToFile(fileName);
        });

        JButton Read = new JButton("Read");
        Read.setSize(80, 20);
        Read.setLocation(200, gamePanel.getHeight() + scoreBoardThree.getHeight());
        add(Read);
        Read.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            System.out.println(controller.getDatafromFile(fileName + "basicData"));
//            System.out.println(controller.getDatafromFile(fileName+"grid"));
            System.out.println(controller.getDatafromFile(fileName + "gridNum"));
            ReadForData readForData = new ReadForData();
            readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
            readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));
            readForData.readDataForGridNum(controller.getDatafromFile(fileName + "gridNum"));
            readForData.readDataForPlayer(controller.getDatafromFile(fileName + "player"));
            System.out.println(controller.getDatafromFile(fileName + "player"));
            readForData.creatMainFrame();


        });

        JButton restart = new JButton("restart");
        restart.setSize(80, 20);
        restart.setLocation(5, gamePanel.getHeight() + scoreBoardThree.getHeight()+40);
        add(restart);
        restart.addActionListener(e -> {
            this.setVisible(false);
            MainFrameThree mainFrameThree = new MainFrameThree(x, y, z);
            mainFrameThree.setVisible(true);

        });

        JButton check = new JButton("check");
        check.setSize(80, 20);
        check.setLocation(100, gamePanel.getHeight() + scoreBoardThree.getHeight()+40);
        add(check);
        check.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            ReadForDataThree readForData = new ReadForDataThree();
            File file = new File("D:\\ideaproject\\project4\\projectdemo\\src\\save\\" + fileName + "basicData" + ".json");
            if (file.exists()) {
                readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
                readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));

                if (readForData.checkForGrid()) {
                    JFrame same = new JFrame();
                    same.setBounds(700, 400, 500, 364);
                    same.setResizable(false);
                    same.setTitle("是正确的存档");

                    JLabel background = new JLabel();
                    background.setBounds(0,0,500,364);
                    background.setIcon(Data.yes);

                    same.add(background);
                    same.setVisible(true);
                } else {
                    JFrame notTheSame = new JFrame();
                    notTheSame.setBounds(700, 400, 500, 375);
                    notTheSame.setResizable(false);
                    notTheSame.setTitle("不是同一个存档");

                    JLabel background = new JLabel();
                    background.setBounds(0,0,500,375);
                    background.setIcon(Data.fail);

                    notTheSame.add(background);

                    notTheSame.setVisible(true);
                }

            } else {
                JFrame empty = new JFrame();
                empty.setBounds(700, 400, 500, 375);
                empty.setResizable(false);
                empty.setTitle("无法找到该命名的存档");

                JLabel background = new JLabel();
                background.setBounds(0,0,500,375);
                background.setIcon(Data.fail);

                empty.add(background);

                empty.setVisible(true);
            }
        });
    }

    public int getxCount() {
        return xCount;
    }

    public int getyCount() {
        return yCount;
    }

    public GamePanelThree getGamePanel() {
        return gamePanel;
    }

    public int getMineCount() {
        return mineCount;
    }

    public void setPlayer(Player[] playersHere) {
        this.p1 = playersHere[0];
        this.p2 = playersHere[1];
        this.p3 = playersHere[2];

    }


}