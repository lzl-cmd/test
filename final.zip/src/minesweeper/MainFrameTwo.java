package minesweeper;

import components.GirdComponentTwo;
import controller.GameControllerTwo;
import entity.GridStatus;
import entity.Player;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.io.File;

public class MainFrameTwo extends JFrame {
    public static GameControllerTwo controller;
    private int xCount;
    private int yCount;
    private int mineCount;
    private GamePanelTwo gamePanel;
    private Player p1;
    private Player p2;
    private int path = 1;

    public MainFrameTwo(int m) {
        //todo: change the count of xCount, yCount and mineCount by passing parameters from constructor
        this.mineCount = m;

        if (mineCount == 10) {
            this.xCount = 9;//grid of row
            this.yCount = 9;// grid of column
        }

        if (mineCount == 40){
            this.xCount = 16;
            this.yCount = 16;
        }

        if (mineCount == 99){
            this.xCount = 16;
            this.yCount = 30;
        }

        this.setTitle("扫雷");
        this.setLayout(null);
        this.setSize(yCount * GirdComponentTwo.gridSize + 20, xCount * GirdComponentTwo.gridSize + 200);
        this.setLocationRelativeTo(null);

        Player p11 = new Player();
        Player p22 = new Player();
        this.p1 = p11;
        this.p2 = p22;

        String name1 = JOptionPane.showInputDialog(this, "玩家1名字");
        System.out.println("p1 :"+name1);
        String name2 = JOptionPane.showInputDialog(this, "玩家2名字");
        System.out.println("p2 :"+name2);



        controller = new GameControllerTwo(p1, p2);
        controller.getP1().setUserName(name1);
        controller.getP2().setUserName(name2);
        GamePanelTwo gamePanel = new GamePanelTwo(xCount, yCount, mineCount);
        controller.setGamePanel(gamePanel);
        ScoreBoard scoreBoard = new ScoreBoard(p1, p2, xCount, yCount);
        controller.setScoreBoard(scoreBoard);
        this.gamePanel = gamePanel;

        this.add(gamePanel);

        this.add(scoreBoard);


        // Change "click" to "Save".
        JButton cheat = new JButton("cheat");
        cheat.setSize(80, 20);
        cheat.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight());
        add(cheat);
        cheat.addActionListener(e -> {
            boolean cheatOrNot = false;
            for (int i = 0; i < xCount; i++) {
                for (int j = 0; j < yCount; j++) {
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                        cheatOrNot = true;
                    }
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CoveredWithMine)) {
                        gamePanel.mineField[i][j].setStatus(GridStatus.CheatOnMine);
                        gamePanel.repaint();
                    }
                }
            }
            if (cheatOrNot) {
                for (int i = 0; i < xCount; i++) {
                    for (int j = 0; j < yCount; j++) {

                        if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                            gamePanel.mineField[i][j].setStatus(GridStatus.CoveredWithMine);
                            gamePanel.repaint();
                        }
                    }
                }
            }
        });
        // Change "click" to "Save".
        JButton clickBtn = new JButton("Save");
        clickBtn.setSize(80, 20);
        clickBtn.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight());
        add(clickBtn);
        clickBtn.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            SaveForDataTwo saveForData = new SaveForDataTwo(this);
            controller.saveDataToFile(fileName + "basicData", saveForData.turnStringForBasic());
            controller.saveDataToFile(fileName + "grid", saveForData.turnStringForGrid());
            controller.saveDataToFile(fileName + "gridNum", saveForData.turnStringForGridNum());
            controller.saveDataToFile(fileName + "player", saveForData.turnStringForPlayers());
            System.out.println("fileName :" + fileName);

//            controller.readFileData(fileName);
//            controller.writeDataToFile(fileName);
        });

        JButton Read = new JButton("Read");
        Read.setSize(80, 20);
        Read.setLocation(200, gamePanel.getHeight() + scoreBoard.getHeight());
        add(Read);
        Read.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            System.out.println(controller.getDatafromFile(fileName + "basicData"));
//            System.out.println(controller.getDatafromFile(fileName+"grid"));
            System.out.println(controller.getDatafromFile(fileName + "gridNum"));
            ReadForDataTwo readForData = new ReadForDataTwo();
            readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
            readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));
            readForData.readDataForGridNum(controller.getDatafromFile(fileName + "gridNum"));
            readForData.readDataForPlayer(controller.getDatafromFile(fileName + "player"));
            System.out.println(controller.getDatafromFile(fileName + "player"));
            readForData.creatMainFrame();


        });

        JButton restart = new JButton("restart");
        restart.setSize(80, 20);
        restart.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight() + 40);
        add(restart);
        restart.addActionListener(e -> {
            this.setVisible(false);
            MainFrameTwo mainFrameTwo = new MainFrameTwo(m);
            mainFrameTwo.setVisible(true);

        });
        JButton check = new JButton("check");
        check.setSize(80, 20);
        check.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight() + 40);
        add(check);
        check.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            ReadForDataTwo readForData = new ReadForDataTwo();
            File file = new File("D:\\ideaproject\\project4\\projectdemo\\src\\save\\" + fileName + "basicData" + ".json");
            if (file.exists()) {
                readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
                readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));

                if (readForData.checkForGrid()) {
                    JFrame same = new JFrame();
                    same.setBounds(700, 400, 500, 364);
                    same.setResizable(false);
                    same.setTitle("是正确的存档");

                    JLabel background = new JLabel();
                    background.setBounds(0,0,500,364);
                    background.setIcon(Data.yes);

                    same.add(background);
                    same.setVisible(true);
                } else {
                    JFrame notTheSame = new JFrame();
                    notTheSame.setBounds(700, 400, 500, 375);
                    notTheSame.setResizable(false);
                    notTheSame.setTitle("不是同一个存档");

                    JLabel background = new JLabel();
                    background.setBounds(0,0,500,375);
                    background.setIcon(Data.fail);

                    notTheSame.add(background);

                    notTheSame.setVisible(true);
                }

            } else {
                JFrame empty = new JFrame();
                empty.setBounds(700, 400, 500, 375);
                empty.setResizable(false);
                empty.setTitle("无法找到该命名的存档");

                JLabel background = new JLabel();
                background.setBounds(0,0,500,375);
                background.setIcon(Data.fail);

                empty.add(background);

                empty.setVisible(true);
            }
        });

    }
    public MainFrameTwo(int m,Player p1,Player p2) {
        //todo: change the count of xCount, yCount and mineCount by passing parameters from constructor
        this.mineCount = m;

        if (mineCount == 10) {
            this.xCount = 9;//grid of row
            this.yCount = 9;// grid of column
        }

        if (mineCount == 40){
            this.xCount = 16;
            this.yCount = 16;
        }

        if (mineCount == 99){
            this.xCount = 16;
            this.yCount = 30;
        }

        this.setTitle("扫雷");
        this.setLayout(null);
        this.setSize(yCount * GirdComponentTwo.gridSize + 20, xCount * GirdComponentTwo.gridSize + 200);
        this.setLocationRelativeTo(null);


        controller = new GameControllerTwo(p1, p2);
        GamePanelTwo gamePanel = new GamePanelTwo(xCount, yCount, mineCount);
        controller.setGamePanel(gamePanel);
        ScoreBoard scoreBoard = new ScoreBoard(p1, p2, xCount, yCount);
        controller.setScoreBoard(scoreBoard);
        this.gamePanel = gamePanel;

        this.add(gamePanel);

        this.add(scoreBoard);


        // Change "click" to "Save".
        JButton cheat = new JButton("cheat");
        cheat.setSize(80, 20);
        cheat.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight());
        add(cheat);
        cheat.addActionListener(e -> {
            boolean cheatOrNot = false;
            for (int i = 0; i < xCount; i++) {
                for (int j = 0; j < yCount; j++) {
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                        cheatOrNot = true;
                    }
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CoveredWithMine)) {
                        gamePanel.mineField[i][j].setStatus(GridStatus.CheatOnMine);
                        gamePanel.repaint();
                    }
                }
            }
            if (cheatOrNot) {
                for (int i = 0; i < xCount; i++) {
                    for (int j = 0; j < yCount; j++) {

                        if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                            gamePanel.mineField[i][j].setStatus(GridStatus.CoveredWithMine);
                            gamePanel.repaint();
                        }
                    }
                }
            }
        });
        // Change "click" to "Save".
        JButton clickBtn = new JButton("Save");
        clickBtn.setSize(80, 20);
        clickBtn.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight());
        add(clickBtn);
        clickBtn.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            SaveForDataTwo saveForData = new SaveForDataTwo(this);
            controller.saveDataToFile(fileName + "basicData", saveForData.turnStringForBasic());
            controller.saveDataToFile(fileName + "grid", saveForData.turnStringForGrid());
            controller.saveDataToFile(fileName + "gridNum", saveForData.turnStringForGridNum());
            controller.saveDataToFile(fileName + "player", saveForData.turnStringForPlayers());
            System.out.println("fileName :" + fileName);

//            controller.readFileData(fileName);
//            controller.writeDataToFile(fileName);
        });

        JButton Read = new JButton("Read");
        Read.setSize(80, 20);
        Read.setLocation(200, gamePanel.getHeight() + scoreBoard.getHeight());
        add(Read);
        Read.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            System.out.println(controller.getDatafromFile(fileName + "basicData"));
//            System.out.println(controller.getDatafromFile(fileName+"grid"));
            System.out.println(controller.getDatafromFile(fileName + "gridNum"));
            ReadForDataTwo readForData = new ReadForDataTwo();
            readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
            readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));
            readForData.readDataForGridNum(controller.getDatafromFile(fileName + "gridNum"));
            readForData.readDataForPlayer(controller.getDatafromFile(fileName + "player"));
            System.out.println(controller.getDatafromFile(fileName + "player"));
            readForData.creatMainFrame();
        });

        JButton restart = new JButton("restart");
        restart.setSize(80, 20);
        restart.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight() + 40);
        add(restart);
        restart.addActionListener(e -> {
            this.setVisible(false);
            MainFrameTwo mainFrameTwo = new MainFrameTwo(m, p1, p2);
        });
        JButton check = new JButton("check");
        check.setSize(80, 20);
        check.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight() + 40);
        add(check);
        check.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            ReadForDataTwo readForData = new ReadForDataTwo();
            File file = new File("D:\\ideaproject\\project4\\projectdemo\\src\\save\\" + fileName + "basicData" + ".json");
            if (file.exists()) {
                readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
                readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));

                if (readForData.checkForGrid()) {
                    JFrame same = new JFrame();
                    same.setBounds(700, 400, 500, 364);
                    same.setResizable(false);
                    same.setTitle("是正确的存档");

                    JLabel background = new JLabel();
                    background.setBounds(0,0,500,364);
                    background.setIcon(Data.yes);

                    same.add(background);
                    same.setVisible(true);
                } else {
                    JFrame notTheSame = new JFrame();
                    notTheSame.setBounds(700, 400, 500, 375);
                    notTheSame.setResizable(false);
                    notTheSame.setTitle("不是同一个存档");

                    JLabel background = new JLabel();
                    background.setBounds(0,0,500,375);
                    background.setIcon(Data.fail);

                    notTheSame.add(background);

                    notTheSame.setVisible(true);
                }

            } else {
                JFrame empty = new JFrame();
                empty.setBounds(700, 400, 500, 375);
                empty.setResizable(false);
                empty.setTitle("无法找到该命名的存档");

                JLabel background = new JLabel();
                background.setBounds(0,0,500,375);
                background.setIcon(Data.fail);

                empty.add(background);

                empty.setVisible(true);
            }
        });

    }

    public MainFrameTwo(int x, int y, int z,int n){
        this.xCount = x;
        this.yCount = y;
        this.mineCount = z;
        this.path = n;
        this.setTitle("扫雷");
        this.setLayout(null);
        this.setSize(yCount * GirdComponentTwo.gridSize + 20, xCount * GirdComponentTwo.gridSize + 200);
        this.setLocationRelativeTo(null);
        this.setResizable(false);

        Player p1 = new Player();
        Player p2 = new Player();

        String name1 = JOptionPane.showInputDialog(this, "玩家1名字");
        System.out.println("p1 :"+name1);
        String name2 = JOptionPane.showInputDialog(this, "玩家2名字");
        System.out.println("p2 :"+name2);

        controller = new GameControllerTwo(p1, p2,path);
        controller.getP1().setUserName(name1);
        controller.getP2().setUserName(name2);
        GamePanelTwo gamePanel = new GamePanelTwo(xCount, yCount, mineCount);
        controller.setGamePanel(gamePanel);
        ScoreBoard scoreBoard = new ScoreBoard(p1, p2, xCount, yCount);
        controller.setScoreBoard(scoreBoard);
        this.gamePanel = gamePanel;

        this.add(gamePanel);
        this.add(scoreBoard);

        JButton cheat = new JButton("cheat");
        cheat.setSize(80, 20);
        cheat.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight());
        add(cheat);
        cheat.addActionListener(e -> {
            boolean cheatOrNot = false;
            for (int i = 0; i < xCount; i++) {
                for (int j = 0; j < yCount; j++) {
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                        cheatOrNot = true;
                    }
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CoveredWithMine)) {
                        gamePanel.mineField[i][j].setStatus(GridStatus.CheatOnMine);
                        gamePanel.repaint();
                    }
                }
            }
            if (cheatOrNot) {
                for (int i = 0; i < xCount; i++) {
                    for (int j = 0; j < yCount; j++) {

                        if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                            gamePanel.mineField[i][j].setStatus(GridStatus.CoveredWithMine);
                            gamePanel.repaint();
                        }
                    }
                }
            }
        });

        // Change "click" to "Save".

        JButton clickBtn = new JButton("Save");
        clickBtn.setSize(80, 20);
        clickBtn.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight());
        add(clickBtn);
        clickBtn.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            SaveForDataTwo saveForData = new SaveForDataTwo(this);
            controller.saveDataToFile(fileName + "basicData", saveForData.turnStringForBasicAno());
            controller.saveDataToFile(fileName + "grid", saveForData.turnStringForGrid());
            controller.saveDataToFile(fileName + "gridNum", saveForData.turnStringForGridNum());
            controller.saveDataToFile(fileName + "player", saveForData.turnStringForPlayers());
            System.out.println("fileName :" + fileName);

//            controller.readFileData(fileName);
//            controller.writeDataToFile(fileName);
        });

        JButton Read = new JButton("Read");
        Read.setSize(80, 20);
        Read.setLocation(200, gamePanel.getHeight() + scoreBoard.getHeight());
        add(Read);
        Read.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            System.out.println(controller.getDatafromFile(fileName + "basicData"));
//            System.out.println(controller.getDatafromFile(fileName+"grid"));
            System.out.println(controller.getDatafromFile(fileName + "gridNum"));
            ReadForDataTwo readForData = new ReadForDataTwo();
            readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
            readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));
            readForData.readDataForGridNum(controller.getDatafromFile(fileName + "gridNum"));
            readForData.readDataForPlayer(controller.getDatafromFile(fileName + "player"));
            System.out.println(controller.getDatafromFile(fileName + "player"));
            readForData.creatMainFrameAno();


        });

        JButton restart = new JButton("restart");
        restart.setSize(80, 20);
        restart.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight()+40);
        add(restart);
        restart.addActionListener(e -> {
            this.setVisible(false);
            MainFrameTwo mainFrameTwo = new MainFrameTwo(x, y, z, n);
            mainFrameTwo.setVisible(true);
        });
        JButton check = new JButton("check");
        check.setSize(80, 20);
        check.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight()+40);
        add(check);
        check.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            ReadForDataTwo readForData = new ReadForDataTwo();
            File file = new File("D:\\ideaproject\\project4\\projectdemo\\src\\save\\" + fileName + "basicData" + ".json");
            if (file.exists()) {
                readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
                readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));

                if (readForData.checkForGrid()) {
                    JFrame same = new JFrame();
                    same.setBounds(700, 400, 500, 364);
                    same.setResizable(false);
                    same.setTitle("是正确的存档");

                    JLabel background = new JLabel();
                    background.setBounds(0,0,500,364);
                    background.setIcon(Data.yes);

                    same.add(background);
                    same.setVisible(true);
                } else {
                    JFrame notTheSame = new JFrame();
                    notTheSame.setBounds(700, 400, 500, 375);
                    notTheSame.setResizable(false);
                    notTheSame.setTitle("不是同一个存档");

                    JLabel background = new JLabel();
                    background.setBounds(0,0,500,375);
                    background.setIcon(Data.fail);

                    notTheSame.add(background);

                    notTheSame.setVisible(true);
                }

            } else {
                JFrame empty = new JFrame();
                empty.setBounds(700, 400, 500, 375);
                empty.setResizable(false);
                empty.setTitle("无法找到该命名的存档");

                JLabel background = new JLabel();
                background.setBounds(0,0,500,375);
                background.setIcon(Data.fail);

                empty.add(background);

                empty.setVisible(true);
            }
        });
    }
    public MainFrameTwo(int x, int y, int z,int n,Player p1,Player p2){
        this.xCount = x;
        this.yCount = y;
        this.mineCount = z;
        this.path = n;
        this.setTitle("扫雷");
        this.setLayout(null);
        this.setSize(yCount * GirdComponentTwo.gridSize + 20, xCount * GirdComponentTwo.gridSize + 200);
        this.setLocationRelativeTo(null);
        this.setResizable(false);


        controller = new GameControllerTwo(p1, p2,path);
        GamePanelTwo gamePanel = new GamePanelTwo(xCount, yCount, mineCount);
        controller.setGamePanel(gamePanel);
        ScoreBoard scoreBoard = new ScoreBoard(p1, p2, xCount, yCount);
        controller.setScoreBoard(scoreBoard);
        this.gamePanel = gamePanel;

        this.add(gamePanel);
        this.add(scoreBoard);

        JButton cheat = new JButton("cheat");
        cheat.setSize(80, 20);
        cheat.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight());
        add(cheat);
        cheat.addActionListener(e -> {
            boolean cheatOrNot = false;
            for (int i = 0; i < xCount; i++) {
                for (int j = 0; j < yCount; j++) {
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                        cheatOrNot = true;
                    }
                    if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CoveredWithMine)) {
                        gamePanel.mineField[i][j].setStatus(GridStatus.CheatOnMine);
                        gamePanel.repaint();
                    }
                }
            }
            if (cheatOrNot) {
                for (int i = 0; i < xCount; i++) {
                    for (int j = 0; j < yCount; j++) {

                        if (gamePanel.mineField[i][j].getStatus().equals(GridStatus.CheatOnMine)) {
                            gamePanel.mineField[i][j].setStatus(GridStatus.CoveredWithMine);
                            gamePanel.repaint();
                        }
                    }
                }
            }
        });

        // Change "click" to "Save".

        JButton clickBtn = new JButton("Save");
        clickBtn.setSize(80, 20);
        clickBtn.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight());
        add(clickBtn);
        clickBtn.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            SaveForDataTwo saveForData = new SaveForDataTwo(this);
            controller.saveDataToFile(fileName + "basicData", saveForData.turnStringForBasicAno());
            controller.saveDataToFile(fileName + "grid", saveForData.turnStringForGrid());
            controller.saveDataToFile(fileName + "gridNum", saveForData.turnStringForGridNum());
            controller.saveDataToFile(fileName + "player", saveForData.turnStringForPlayers());
            System.out.println("fileName :" + fileName);

//            controller.readFileData(fileName);
//            controller.writeDataToFile(fileName);
        });

        JButton Read = new JButton("Read");
        Read.setSize(80, 20);
        Read.setLocation(200, gamePanel.getHeight() + scoreBoard.getHeight());
        add(Read);
        Read.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            System.out.println(controller.getDatafromFile(fileName + "basicData"));
//            System.out.println(controller.getDatafromFile(fileName+"grid"));
            System.out.println(controller.getDatafromFile(fileName + "gridNum"));
            ReadForDataTwo readForData = new ReadForDataTwo();
            readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
            readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));
            readForData.readDataForGridNum(controller.getDatafromFile(fileName + "gridNum"));
            readForData.readDataForPlayer(controller.getDatafromFile(fileName + "player"));
            System.out.println(controller.getDatafromFile(fileName + "player"));
            readForData.creatMainFrameAno();


        });


        JButton restart = new JButton("restart");
        restart.setSize(80, 20);
        restart.setLocation(5, gamePanel.getHeight() + scoreBoard.getHeight()+40);
        add(restart);
        restart.addActionListener(e -> {
            this.setVisible(false);
            MainFrameTwo mainFrameTwo = new MainFrameTwo(x, y, z, n, p1, p2);
            mainFrameTwo.setVisible(true);

        });

        JButton check = new JButton("check");
        check.setSize(80, 20);
        check.setLocation(100, gamePanel.getHeight() + scoreBoard.getHeight()+40);
        add(check);
        check.addActionListener(e -> {
            String fileName = JOptionPane.showInputDialog(this, "input here");
            ReadForDataTwo readForData = new ReadForDataTwo();
            File file = new File("D:\\ideaproject\\project4\\projectdemo\\src\\save\\" + fileName + "basicData" + ".json");
            if (file.exists()) {
                readForData.readDataForBasic(controller.getDatafromFile(fileName + "basicData"));
                readForData.readDataForGrid(controller.getDatafromFile(fileName + "grid"));

                if (readForData.checkForGrid()) {
                    JFrame same = new JFrame();
                    same.setBounds(700, 400, 500, 364);
                    same.setResizable(false);
                    same.setTitle("是正确的存档");

                    JLabel background = new JLabel();
                    background.setBounds(0,0,500,364);
                    background.setIcon(Data.yes);

                    same.add(background);
                    same.setVisible(true);
                } else {
                    JFrame notTheSame = new JFrame();
                    notTheSame.setBounds(700, 400, 500, 375);
                    notTheSame.setResizable(false);
                    notTheSame.setTitle("不是同一个存档");

                    JLabel background = new JLabel();
                    background.setBounds(0,0,500,375);
                    background.setIcon(Data.fail);

                    notTheSame.add(background);

                    notTheSame.setVisible(true);
                }

            } else {
                JFrame empty = new JFrame();
                empty.setBounds(700, 400, 500, 375);
                empty.setResizable(false);
                empty.setTitle("无法找到该命名的存档");

                JLabel background = new JLabel();
                background.setBounds(0,0,500,375);
                background.setIcon(Data.fail);

                empty.add(background);

                empty.setVisible(true);
            }
        });
    }



    public int getxCount() {
        return xCount;
    }

    public int getyCount() {
        return yCount;
    }

    public GamePanelTwo getGamePanel() {
        return gamePanel;
    }

    public int getMineCount() {
        return mineCount;
    }
    public int getPath(){
        return path;
    }
    public void setPlayer(Player[] players) {
        this.p1 = players[0];
        this.p2 = players[1];
    }
}

