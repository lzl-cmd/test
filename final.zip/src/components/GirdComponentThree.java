package components;

import controller.GameController;
import entity.GridStatus;
import minesweeper.Data;
import minesweeper.MainFrameThree;
import minesweeper.MainFrameTwo;

import javax.swing.*;
import java.awt.*;

public class GirdComponentThree extends BasicComponent {
    public static int gridSize = 30;
    private int xCount;
    private int yCount;
    private static ImageIcon flag = new ImageIcon("src\\minesweeper\\images\\flag.jpg");
    private static ImageIcon bomb = new ImageIcon("src\\minesweeper\\images\\bomb.jpg");

    private int row;
    private int col;
    private GridStatus status = GridStatus.CoveredWithGrid;
    private int content = 0;

    public GirdComponentThree(int x, int y, int xCount, int yCount) {
        this.setSize(gridSize, gridSize);
        this.row = x;
        this.col = y;
        this.xCount = xCount;
        this.yCount = yCount;
    }

    public GridStatus getStatus() {
        return status;
    }

    public void setStatus(GridStatus status) {
        this.status = status;
    }


    @Override
    public void onMouseLeftClicked() {
        GameController.clickSound();

//        MainFrame.controller.testForInitial();
        System.out.printf("Gird (%d,%d) is left-clicked.\n", row, col);
        if (this.status == GridStatus.CoveredWithGrid) {
            this.status = GridStatus.Clicked;
            System.out.println(this.content);
            MainFrameThree.controller.openAll(row, col);
            repaint();
            MainFrameThree.controller.nextTurn();
        }
        if (this.status == GridStatus.CoveredWithMine || this.status == GridStatus.CheatOnMine) {
            if (MainFrameThree.controller.creatAgain()) {
                MainFrameThree.controller.repaintForFirstClickOnMine(row, col);
                this.status = GridStatus.Clicked;
                MainFrameThree.controller.openAll(row, col);
                repaint();
            } else {
                System.out.println("点到雷了");
                this.status = GridStatus.ClickedOnMine;
                repaint();
                MainFrameThree.controller.getOnTurnPlayer().costScore();

                int count = 1;
                for (int i = 0; i <= MainFrameThree.controller.getGamePanel().getxCount() - 1; i++) {
                    for (int j = 0; j <= MainFrameThree.controller.getGamePanel().getyCount() - 1; j++) {

                        if (MainFrameThree.controller.getGamePanel().mineField[i][j].getStatus().equals(GridStatus.CheatOnMine) || MainFrameThree.controller.getGamePanel().mineField[i][j].getStatus().equals(GridStatus.CoveredWithMine)) {
                            count = count + 1;
                        }
                    }
                }
                count = count - 1;
                System.out.println(count);

                JFrame remain = new JFrame();

                remain.setVisible(true);
                remain.setLayout(null);
                remain.setBounds(1360,540,576,522);
                remain.setResizable(false);
                remain.setTitle("还有"+count+"个雷！");
                remain.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

                JLabel number = new JLabel();
                number.setBounds(0,0,576,522);
                number.setIcon(Data.end);
                remain.add(number);

                int x = MainFrameThree.controller.getP1().getScore();
                int y = MainFrameThree.controller.getP2().getScore();
                int z = MainFrameThree.controller.getP3().getScore();
                int max, m, min;
                max = Math.max(Math.max(x, y), z);
                min = Math.min(Math.min(x, y), z);
                m = x + y + z - max - min;
                if (count != 0) {
                    if (max - m <= count) {
                        MainFrameThree.controller.nextTurn();
                    } else {
                        //游戏结束
                        JFrame endFrame = new JFrame();
                        endFrame.setTitle("游戏结束");
                        endFrame.setVisible(true);
                        endFrame.setLayout(null);
                        endFrame.setBounds(700, 400, 700, 522);
                        endFrame.setResizable(false);
                        endFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

                        JLabel background;
                        if (MainFrameThree.controller.getP1().getScore() >= Math.max(MainFrameThree.controller.getP2().getScore(), MainFrameThree.controller.getP3().getScore())) {
                            background = new JLabel(String.format("%s 获胜", MainFrameThree.controller.getP1().getUserName()));
                        } else if (MainFrameThree.controller.getP2().getScore() > Math.max(MainFrameThree.controller.getP1().getScore(), MainFrameThree.controller.getP3().getScore())) {
                            background = new JLabel(String.format("%s 获胜", MainFrameThree.controller.getP2().getUserName()));
                        } else {
                            background = new JLabel(String.format("%s 获胜", MainFrameThree.controller.getP3().getUserName()));
                        }

                        background.setBounds(0, 0, 700, 522);
                        background.setIcon(Data.end);
                        endFrame.add(background);
                    }
                } else {
                    //游戏结束
                    JFrame endFrame = new JFrame();
                    endFrame.setTitle("游戏结束");
                    endFrame.setVisible(true);
                    endFrame.setLayout(null);
                    endFrame.setBounds(700, 400, 700, 522);
                    endFrame.setResizable(false);
                    endFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

                    JLabel background;
                    if (MainFrameThree.controller.getP1().getScore() >= Math.max(MainFrameThree.controller.getP2().getScore(), MainFrameThree.controller.getP3().getScore())) {
                        background = new JLabel(String.format("%s 获胜", MainFrameThree.controller.getP1().getUserName()));
                    } else if (MainFrameThree.controller.getP2().getScore() > Math.max(MainFrameThree.controller.getP1().getScore(), MainFrameThree.controller.getP3().getScore())) {
                        background = new JLabel(String.format("%s 获胜", MainFrameThree.controller.getP2().getUserName()));
                    } else {
                        background = new JLabel(String.format("%s 获胜", MainFrameThree.controller.getP3().getUserName()));
                    }

                    background.setBounds(0, 0, 700, 522);
                    background.setIcon(Data.end);
                    endFrame.add(background);
                }
            }
        }
        //TODO: 在左键点击一个格子的时候，还需要做什么？

    }

    @Override
    public void onMouseRightClicked() {
        GameController.clickSound();

        System.out.printf("Gird (%d,%d) is right-clicked.\n", row, col);
        if (this.status == GridStatus.CoveredWithGrid) {
            System.out.println("旗子插错了");
            this.status = GridStatus.Clicked;
            repaint();
            MainFrameThree.controller.getOnTurnPlayer().addMistake();

            int count = 1;
            for (int i = 0; i <= MainFrameThree.controller.getGamePanel().getxCount() - 1; i++) {
                for (int j = 0; j <= MainFrameThree.controller.getGamePanel().getyCount() - 1; j++) {

                    if (MainFrameThree.controller.getGamePanel().mineField[i][j].getStatus().equals(GridStatus.CheatOnMine) || MainFrameThree.controller.getGamePanel().mineField[i][j].getStatus().equals(GridStatus.CoveredWithMine)) {
                        count = count + 1;
                    }
                }
            }
            count = count - 1;
            System.out.println(count);

            int x = MainFrameThree.controller.getP1().getScore();
            int y = MainFrameThree.controller.getP2().getScore();
            int z = MainFrameThree.controller.getP3().getScore();
            int max, m, min;
            max = Math.max(Math.max(x, y), z);
            min = Math.min(Math.min(x, y), z);
            m = x + y + z - max - min;
            if (count != 0) {
                if (max - m <= count) {
                    MainFrameThree.controller.nextTurn();
                } else {
                    //游戏结束

                    JFrame endFrame = new JFrame();
                    endFrame.setTitle("游戏结束");
                    endFrame.setVisible(true);
                    endFrame.setLayout(null);
                    endFrame.setBounds(700, 400, 700, 522);
                    endFrame.setResizable(false);
                    endFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

                    JLabel background;
                    if (MainFrameThree.controller.getP1().getScore() >= Math.max(MainFrameThree.controller.getP2().getScore(), MainFrameThree.controller.getP3().getScore())) {
                        background = new JLabel(String.format("%s 获胜", MainFrameThree.controller.getP1().getUserName()));
                    } else if (MainFrameThree.controller.getP2().getScore() > Math.max(MainFrameThree.controller.getP1().getScore(), MainFrameThree.controller.getP3().getScore())) {
                        background = new JLabel(String.format("%s 获胜", MainFrameThree.controller.getP2().getUserName()));
                    } else {
                        background = new JLabel(String.format("%s 获胜", MainFrameThree.controller.getP3().getUserName()));
                    }

                    background.setBounds(0, 0, 700, 522);
                    background.setIcon(Data.end);
                    endFrame.add(background);
                }
            } else {
                //游戏结束
                JFrame endFrame = new JFrame();
                endFrame.setTitle("游戏结束");
                endFrame.setVisible(true);
                endFrame.setLayout(null);
                endFrame.setBounds(700, 400, 700, 522);
                endFrame.setResizable(false);
                endFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

                JLabel background;
                if (MainFrameThree.controller.getP1().getScore() >= Math.max(MainFrameThree.controller.getP2().getScore(), MainFrameThree.controller.getP3().getScore())) {
                    background = new JLabel(String.format("%s 获胜", MainFrameThree.controller.getP1().getUserName()));
                } else if (MainFrameThree.controller.getP2().getScore() > Math.max(MainFrameThree.controller.getP1().getScore(), MainFrameThree.controller.getP3().getScore())) {
                    background = new JLabel(String.format("%s 获胜", MainFrameThree.controller.getP2().getUserName()));
                } else {
                    background = new JLabel(String.format("%s 获胜", MainFrameThree.controller.getP3().getUserName()));
                }

                background.setBounds(0, 0, 700, 522);
                background.setIcon(Data.end);
                endFrame.add(background);
            }

        }
        if (this.status == GridStatus.CoveredWithMine || this.status == GridStatus.CheatOnMine) {
            this.status = GridStatus.FlagOnMine;
            repaint();
            MainFrameThree.controller.getOnTurnPlayer().addScore();

            int count = 1;
            for (int i = 0; i <= MainFrameThree.controller.getGamePanel().getxCount() - 1; i++) {
                for (int j = 0; j <= MainFrameThree.controller.getGamePanel().getyCount() - 1; j++) {

                    if (MainFrameThree.controller.getGamePanel().mineField[i][j].getStatus().equals(GridStatus.CheatOnMine) || MainFrameThree.controller.getGamePanel().mineField[i][j].getStatus().equals(GridStatus.CoveredWithMine)) {
                        count = count + 1;
                    }
                }
            }
            count = count - 1;
            System.out.println(count);

            JFrame remain = new JFrame();

            remain.setVisible(true);
            remain.setLayout(null);
            remain.setBounds(1360,540,576,522);
            remain.setResizable(false);
            remain.setTitle("还有"+count+"个雷！");
            remain.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

            JLabel number = new JLabel();
            number.setBounds(0,0,576,522);
            number.setIcon(Data.end);
            remain.add(number);

            int x = MainFrameThree.controller.getP1().getScore();
            int y = MainFrameThree.controller.getP2().getScore();
            int z = MainFrameThree.controller.getP3().getScore();
            int max, m, min;
            max = Math.max(Math.max(x, y), z);
            min = Math.min(Math.min(x, y), z);
            m = x + y + z - max - min;
            if (count != 0) {
                if (max - m <= count) {
                    MainFrameThree.controller.nextTurn();
                } else {
                    //游戏结束
                    JFrame endFrame = new JFrame();
                    endFrame.setTitle("游戏结束");
                    endFrame.setVisible(true);
                    endFrame.setLayout(null);
                    endFrame.setBounds(700, 400, 700, 522);
                    endFrame.setResizable(false);
                    endFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

                    JLabel background;
                    if (MainFrameThree.controller.getP1().getScore() >= Math.max(MainFrameThree.controller.getP2().getScore(), MainFrameThree.controller.getP3().getScore())) {
                        background = new JLabel(String.format("%s 获胜", MainFrameThree.controller.getP1().getUserName()));
                    } else if (MainFrameThree.controller.getP2().getScore() > Math.max(MainFrameThree.controller.getP1().getScore(), MainFrameThree.controller.getP3().getScore())) {
                        background = new JLabel(String.format("%s 获胜", MainFrameThree.controller.getP2().getUserName()));
                    } else {
                        background = new JLabel(String.format("%s 获胜", MainFrameThree.controller.getP3().getUserName()));
                    }

                    background.setBounds(0, 0, 700, 522);
                    background.setIcon(Data.end);
                    endFrame.add(background);
                }
            } else {
                //游戏结束
                JFrame endFrame = new JFrame();
                endFrame.setTitle("游戏结束");
                endFrame.setVisible(true);
                endFrame.setLayout(null);
                endFrame.setBounds(700, 400, 700, 522);
                endFrame.setResizable(false);
                endFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

                JLabel background;
                if (MainFrameThree.controller.getP1().getScore() >= Math.max(MainFrameThree.controller.getP2().getScore(), MainFrameThree.controller.getP3().getScore())) {
                    background = new JLabel(String.format("%s 获胜", MainFrameThree.controller.getP1().getUserName()));
                } else if (MainFrameThree.controller.getP2().getScore() > Math.max(MainFrameThree.controller.getP1().getScore(), MainFrameThree.controller.getP3().getScore())) {
                    background = new JLabel(String.format("%s 获胜", MainFrameThree.controller.getP2().getUserName()));
                } else {
                    background = new JLabel(String.format("%s 获胜", MainFrameThree.controller.getP3().getUserName()));
                }

                background.setBounds(0, 0, 700, 522);
                background.setIcon(Data.end);
                endFrame.add(background);
            }
        }
        //TODO: 在右键点击一个格子的时候，还需要做什么？
    }

    public void draw(Graphics g) {

        if (this.status == GridStatus.CoveredWithGrid) {
            g.setColor(Color.CYAN);
            g.fillRect(0, 0, getWidth() - 1, getHeight() - 1);
        }
        if (this.status == GridStatus.Clicked) {
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, getWidth() - 1, getHeight() - 1);
            g.setColor(Color.BLACK);
            g.drawString(Integer.toString(content), getWidth() / 2 - 5, getHeight() / 2 + 5);

        }
        if (this.status == GridStatus.Flag) {

            g.setColor(Color.LIGHT_GRAY);
            g.fillRect(0, 0, getWidth() - 1, getHeight() - 1);
            g.setColor(Color.RED);
            g.drawString("F", getWidth() / 2 - 5, getHeight() / 2 + 5);
        }
        if (this.status == GridStatus.FlagOnMine) {
            g.drawImage(flag.getImage(), 0, 0, this);
        }
        if (this.status == GridStatus.CoveredWithMine) {

            g.setColor(Color.CYAN);
            g.fillRect(0, 0, getWidth() - 1, getHeight() - 1);
            g.setColor(Color.CYAN);
            g.drawString("F", getWidth() / 2 - 5, getHeight() / 2 + 5);
        }
        if (this.status == GridStatus.ClickedOnMine) {
            g.drawImage(bomb.getImage(), 0, 0, this);
//            g.setColor(Color.RED);
//            g.fillRect(0, 0, getWidth() - 1, getHeight() - 1);
//            g.setColor(Color.RED);
//            g.drawString("F", getWidth() / 2 - 5, getHeight() / 2 + 5);
        }
        if (this.status == GridStatus.FlagOnGrid) {
            g.setColor(Color.RED);
            g.fillRect(0, 0, getWidth() - 1, getHeight() - 1);
            g.drawImage(flag.getImage(), 0, 0, this);

            g.setColor(Color.RED);
        }
        if (this.status == GridStatus.CheatOnMine) {
            g.setColor(Color.RED);
            g.fillRect(0, 0, getWidth() - 1, getHeight() - 1);
            g.setColor(Color.RED);
            g.drawString("F", getWidth() / 2 - 5, getHeight() / 2 + 5);
        }

    }

    public int getContent() {
        return content;
    }

    public void setContent(int content) {
        this.content = content;
    }

    @Override
    public void paintComponent(Graphics g) {
        super.printComponents(g);
        draw(g);
    }
}



