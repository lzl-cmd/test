
import controller.GameController;
import entity.musicStuff;
import minesweeper.*;


import javax.swing.*;


public class Main {
    public static void main(String[] args) {
        GameController.bgm();

//        String filepath = "src\\music\\music.wav";
//        musicStuff musicObject = new musicStuff();
//        musicObject.playMusic(filepath);
        SwingUtilities.invokeLater(() -> {

            WelcomeFrame welcomeFrame = new WelcomeFrame();
            welcomeFrame.setVisible(true);
        });

    }
}





