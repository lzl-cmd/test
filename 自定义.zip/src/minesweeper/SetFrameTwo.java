package minesweeper;

import javax.swing.*;

public class SetFrameTwo extends JFrame {

    public SetFrameTwo(){

        String x = JOptionPane.showInputDialog(this, "宽度");
        System.out.println("宽度 :"+x);
        String y = JOptionPane.showInputDialog(this, "高度");
        System.out.println("高度 :"+y);
        String z = JOptionPane.showInputDialog(this, "雷数");
        System.out.println("雷数 :"+z);
        String n = JOptionPane.showInputDialog(this, "步数");



        int width = Integer.parseInt(x);
        int height = Integer.parseInt(y);
        int number = Integer.parseInt(z);
        int path = Integer.parseInt(n);

        if (number <= width*height/2){
            MainFrameTwo mainFrameTwo = new MainFrameTwo(width,height,number,path);
            mainFrameTwo.setVisible(true);
        }else {
            ErrorFrame errorFrame = new ErrorFrame();
            errorFrame.setVisible(true);
        }

    }


}
