package minesweeper;

import javax.swing.*;
import java.awt.*;

public class ErrorFrame extends JFrame {

    public ErrorFrame(){

        this.setTitle("雷数错误");
        this.setVisible(true);
        this.setLayout(null);
        this.setBounds(700,400,500,500);
        this.setResizable(false);

        JLabel background = new JLabel();
        background.setBounds(0,0,500,500);
        background.setIcon(Data.error);

        Container container = getContentPane();
        container.add(background);

    }

}
