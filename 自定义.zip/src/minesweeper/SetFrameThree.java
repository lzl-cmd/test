package minesweeper;

import javax.swing.*;

public class SetFrameThree extends JFrame {

    public SetFrameThree(){

        String x = JOptionPane.showInputDialog(this, "宽度");
        System.out.println("宽度 :"+x);
        String y = JOptionPane.showInputDialog(this, "高度");
        System.out.println("高度 :"+y);
        String z = JOptionPane.showInputDialog(this, "雷数");
        System.out.println("雷数 :"+z);


        int width = Integer.parseInt(x);
        int height = Integer.parseInt(y);
        int number = Integer.parseInt(z);

        if (number <= width*height/2){
            MainFrameThree mainFrameThree = new MainFrameThree(width,height,number);
            mainFrameThree.setVisible(true);
        }else {
            ErrorFrame errorFrame = new ErrorFrame();
            errorFrame.setVisible(true);
        }

    }

}
